Data for this chapter was downloaded from MassGIS website
OpenSpace - http://www.mass.gov/mgis/osp.htm
Hospitals - http://www.mass.gov/mgis/hospitals.htm
Roads - http://www.mass.gov/mgis/eotroads.htm

In a PostGIS 1.5+ enabled database

Get into psql (TIP: You can launch psql from PgAdmin Plugins menu - make sure to select the database first before you launch)
run
\i /path/to/data/ch11_data.sql

SELECT populate_geometry_columns('ch11.ma_eotmajroads'::regclass);
SELECT populate_geometry_columns('ch11.ma_hospitals'::regclass);
SELECT populate_geometry_columns('ch11.ma_openspace'::regclass);
SELECT populate_geometry_columns('ch11.ma_rtemarkers'::regclass);

--- alternatively --
"C:\Program Files\PostgresQL\8.4\bin\psql" -h localhost -d postgis_in_action -U postgres -f ch11_data.sql

-- All the code for the web applications described in the chapter can be found in the webapp folder