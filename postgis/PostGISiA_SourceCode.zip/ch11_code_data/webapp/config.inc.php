<?php
define("DSN", 'postgres://serverhere:passwordhere@userhere:5432/postgis_in_action?persist');
?>
