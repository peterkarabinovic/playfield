var lat=43.66596;
var lon=-73.13868;
var zoom=6;
var map, lyrMapnik, lyryahoo,lyrStates, lonlat, panel, gridPanel;
var prj4326 = new OpenLayers.Projection("EPSG:4326");
var prjmerc = new OpenLayers.Projection("EPSG:900913");
lyrMapnik = new OpenLayers.Layer.OSM.Mapnik("OSM Mapnik");

lyryahoo = new OpenLayers.Layer.Yahoo(
    "Yahoo Hybrid",
    {'type': YAHOO_MAP_HYB, 'sphericalMercator': true}
  );
map = new OpenLayers.Map ( {
    controls:[ new OpenLayers.Control.Navigation(),
      new OpenLayers.Control.PanZoomBar(), new OpenLayers.Control.LayerSwitcher()
       ],
    maxResolution: 156543.0399,
    numZoomLevels: 20,
    units: 'm',
    projection: prjmerc,
    displayProjection: prj4326
  } );


lonlat = new OpenLayers.LonLat(lon, lat).transform(prj4326, prjmerc);
lyrStates = new OpenLayers.Layer.Vector("States");

Ext.onReady(function() {
   dtstate = new GeoExt.data.FeatureStore({
        layer: lyrStates,
        fields: [
            {name: 'state_name', type: 'string'},
            {name: 'year_adm', type: 'string'}
        ],
        proxy: new GeoExt.data.ProtocolProxy({
            protocol: new OpenLayers.Protocol.HTTP({
                url: "datafeeder.php?format=json",
                format: new OpenLayers.Format.GeoJSON(),
                bbox: map.getExtent()
            })
        }),
        autoLoad: true,
        setParamsAsOptions: true
    });
     
    gridPanel = new Ext.grid.GridPanel({
        title: "States",
        store: dtstate,
        layout: 'fit',
        columns: [{
            header: "State",
            dataIndex: "state_name", sortable: true
        }, {
            header: "Year Admitted",
            dataIndex: "year_adm", sortable: true
        }],
        sm: new GeoExt.grid.FeatureSelectionModel() 
    });
    

  panel = new Ext.Panel({
    id:'main-panel',
    baseCls:'x-plain',
    renderTo: Ext.getBody(),
    layout:'table',
    layoutConfig: {columns:2},
    defaults: {frame:false, height: 600},
    items:[{
      title:'New England',
      xtype: "gx_mappanel",
      map: map,
      layers: [lyrMapnik, lyryahoo, lyrStates],
      zoom: zoom,
      extent: [-8879149, 4938750,-7453286, 6017794],
      center: lonlat,
      width: 500
    },gridPanel
    ]
  });


});
