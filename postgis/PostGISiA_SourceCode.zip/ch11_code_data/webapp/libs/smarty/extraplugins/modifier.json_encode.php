<?php
function smarty_modifier_json_encode($string)
{
    return json_encode($string);
}

?>
