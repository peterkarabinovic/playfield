var lat=43.66596;
var lon=-73.13868;
var zoom=6;
var map, lyrMapnik, lyryahoo, lonlat;
var prj4326 = new OpenLayers.Projection("EPSG:4326");
var prjmerc = new OpenLayers.Projection("EPSG:900913");
lyrMapnik = new OpenLayers.Layer.OSM.Mapnik("OSM Mapnik");

lyryahoo = new OpenLayers.Layer.Yahoo(
		"Yahoo Hybrid",
		{'type': YAHOO_MAP_HYB, 'sphericalMercator': true}
	);
 map = new OpenLayers.Map ( {
		controls:[ new OpenLayers.Control.Navigation(),
			new OpenLayers.Control.PanZoomBar(), new OpenLayers.Control.LayerSwitcher()
		   ],
		maxResolution: 156543.0399,
		numZoomLevels: 20,
		units: 'm',
		projection: prjmerc,
		displayProjection: prj4326
	} );
 
lonlat = new OpenLayers.LonLat(lon, lat).transform(prj4326, prjmerc)
Ext.onReady(function() {
	new Ext.Window({
		title: "New England",
		height: 600,
		width: 600,
		closable: false,
		collapsible: true,
		items: [{
			xtype: "gx_mappanel",
			map: map,
			layers: [lyrMapnik, lyryahoo],
			zoom: zoom,
			extent: [-8879149, 4938750,-7453286, 6017794],
			center: lonlat
		}]
	}).show();

});
