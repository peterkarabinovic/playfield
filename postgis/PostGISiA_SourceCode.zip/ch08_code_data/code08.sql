SELECT c.city, b.bridge_nam, ST_Distance(c.the_geom, b.the_geom) As dist_ft
FROM sf.cities AS c CROSS JOIN sf.bridges As b;

-- Listing 8.1 Basic ST_DWithin query
SELECT DISTINCT c.city, b.bridge_nam,                                  -- #1
ST_Distance(c.the_geom, b.the_geom) As dist_ft
FROM sf.cities AS c INNER JOIN sf.bridges As b 
	ON ST_DWithin(c.the_geom, b.the_geom,1000)
WHERE c.city = 'SAN FRANCISCO';

SELECT ST_Buffer(ST_Union(c.the_geom),1000) As sf_1000ft               -- #2 
FROM sf.cities As c
WHERE c.city = 'SAN FRANCISCO';
-- #1 ST_DWithin query
-- #2 Buffer for visualization


-- Using ST_Intersects
SELECT c.city, b.bridge_nam
FROM sf.cities AS c INNER JOIN 
	sf.bridges As b ON ST_Intersects(c.the_geom, b.the_geom);


CREATE SCHEMA utility;
ALTER DATABASE postgis_in_action set search_path=public,utility;
-- Listing 8.2 Create a simple units conversion table
set search_path=utility,public;
CREATE TABLE utility.lu_units (
    unit character varying(50) NOT NULL PRIMARY KEY,
    unit_to_meters numeric(10,4)
);

INSERT INTO lu_units (unit, unit_to_meters) VALUES ('mile', 1609.3400);
INSERT INTO lu_units (unit, unit_to_meters) VALUES ('kilometer', 1000);
INSERT INTO lu_units (unit, unit_to_meters) VALUES ('meter', 1);
INSERT INTO lu_units (unit, unit_to_meters) VALUES ('feet', 0.3048);


-- Listing 8.3 What bridges are within half-mile of San Francisco
SELECT DISTINCT c.city, b.bridge_nam,                                  
    ST_Distance(c.the_geom, b.the_geom) As dist_ft,                  
ST_Distance(c.the_geom, b.the_geom)*u.convfactor As dist_miles         --#1
FROM (
	SELECT uf.unit_to_meters/um.unit_to_meters As convfactor          --#2
            FROM lu_units As uf CROSS JOIN lu_units As um
                WHERE uf.unit = 'feet' and um.unit = 'mile') As u 
	CROSS JOIN sf.cities AS c 
     
               INNER JOIN sf.bridges As b ON (
    ST_DWithin(c.the_geom, b.the_geom,0.5/u.convfactor))               --#3
WHERE c.city = 'SAN FRANCISCO'
ORDER BY dist_miles;
--#1 convert feet to miles
--#2 conversion table
--#3 convert 0.5 mile to 2640 ft


-- Listing 8.4 Example sql function to convert between two units
-- 1 function
CREATE OR REPLACE FUNCTION utility.units_from_to(unitfrom character varying, unitto character varying, thevalue double precision)
  RETURNS double precision AS
$$
	WITH u(unit, unit_to_meters)  AS
	(VALUES ('mile', 1609.3400), 
			('kilometer', 1000), 
			('meter',1),
			('feet', 0.3048) 
		)
	SELECT ufrom.unit_to_meters/uto.unit_to_meters*$3
            FROM 
		 u As ufrom CROSS JOIN u As uto
                WHERE ufrom.unit = $1 and uto.unit = $2;
$$
  LANGUAGE 'sql' IMMUTABLE STRICT
  COST 10;

-- Listing 8.5 Using unit conversion function
SELECT DISTINCT c.city, b.bridge_nam, 
	ST_Distance(c.the_geom, b.the_geom) As dist_ft,
	-- 1 display distance in miles by converting native feet to miles
units_from_to('feet','mile',
		ST_Distance(c.the_geom, b.the_geom) ) As dist_miles
FROM 
	sf.cities AS c INNER JOIN sf.bridges As b ON (
-- 2 take as input 0.5 miles and convert to native California state plane feet
		ST_DWithin(c.the_geom, b.the_geom, units_from_to('mile','feet',0.5) ) )
WHERE c.city = 'SAN FRANCISCO'
ORDER BY dist_miles;
 
-- Listing 8.6 Compare distance measurement accuracy of various spatial refs
SELECT DISTINCT c.city, b.bridge_nam, 
  CAST(units_from_to('feet','meter',                                   --#1
    ST_Distance(c.the_geom, b.the_geom)) As numeric(10,2)) As ca_m,
    CAST(ST_Distance(ST_Transform(c.the_geom,2163),                    --#2        
        ST_Transform(b.the_geom,2163) ) As numeric(10,2) )  As natea_m,
CAST( ST_Distance( ST_Transform(c.the_geom,3785),                      --#3         
   ST_Transform(b.the_geom,3785)  
     ) As numeric(10,2) )  As wm_m,
CAST( ST_Distance(
    geography(ST_Transform(c.the_geom,4326)),                          --#4                 
    geography(ST_Transform(b.the_geom,4326))) As numeric(10,2))
        As geog_spheroid_m
FROM 
    sf.cities AS c 
    INNER JOIN sf.bridges As b 
    ON (ST_DWithin(c.the_geom, b.the_geom, units_from_to('mile','feet',0.5) ) )
WHERE ST_Distance(c.the_geom, b.the_geom) > 0;
--#1 feet to meters
--#2 transform to naea (2163)
--#3 transform to web Mercator (3785)
--#4 geometry to geography dist spheroid

 
-- Listing 8.7 Distances between cities in kilometers using various projections
SELECT w1.name As city1, w2.name As city2,
    CAST(
        ST_Distance_Sphere(w1.the_geom,w2.the_geom)/1000 
            As integer) As sp, 
    CAST(ST_Distance_Spheroid(
        w1.the_geom,
        w2.the_geom, 
        spheroid('SPHEROID["WGS 84",6378137,298.257223563]') 
    )/1000 As integer) As spwgs84,
    CAST(ST_Distance( ST_Transform(w1.the_geom, 3785),
            ST_Transform(w2.the_geom, 3785)
        )/1000 As integer) As wm
FROM world.cities As w1 INNER JOIN
    world.cities As w2 ON (w1.name <> w2.name)
WHERE w1.name IN('Beijing', 'Cairo', 'Rio de Janeiro', 'Sydney')
    AND w2.name IN('Jerusalem', 'Melbourne', 'Philadelphia', 'Shanghai', 'Sao Paulo')
ORDER BY w1.name, w2.name;

-- Listing 8.8 Area calculations for large objects
SELECT city, 
	CAST(casp_m/1000 As integer ) As casp, 
	CAST(geog_m/1000 As integer ) As geog,
	CAST(naea_m/1000 As integer ) As naea,
	CAST(wm_m/1000 As integer ) As wm,
	CAST((1 - c.geog_m/c.casp_m)*100 As numeric(10,2)) As pgeog,
	CAST((1 - c.naea_m/c.casp_m)*100 As numeric(10,2)) As pnaea,
	CAST((1 - c.naea_m/c.wm_m)*100 As numeric(10,2)) As pwm
FROM (SELECT city, the_geom, ST_Area(the_geom)*POWER(0.3048,2) As casp_m,
		ST_Area(geography(ST_Transform(the_geom, 4326))) As geog_m,
		ST_Area(ST_Transform(the_geom, 2163)) As naea_m,
		ST_Area(ST_Transform(the_geom, 3785)) As wm_m
	FROM sf.distinct_cities ) As c
WHERE ST_Area(c.the_geom) BETWEEN 13271000 AND 22751000  -- Small Sqft
	OR ST_Area(c.the_geom) > 10400000000 -- Large Sqft
ORDER BY ST_Area(c.the_geom) ASC;


-- utmzone function from: http://trac.osgeo.org/postgis/wiki/UsersWikiplpgsqlfunctionsDistance

 CREATE OR REPLACE FUNCTION utility.utmzone(geometry)
   RETURNS integer AS
 $BODY$
 DECLARE
     geomgeog geometry;
     zone int;
     pref int;

 BEGIN
     geomgeog:= ST_Transform($1,4326);

     IF (ST_Y(geomgeog))>0 THEN
        pref:=32600;
     ELSE
        pref:=32700;
     END IF;

     zone:=floor((ST_X(geomgeog)+180)/6)+1;

     RETURN zone+pref;
 END;
 $BODY$ LANGUAGE 'plpgsql' IMMUTABLE
   COST 100;


-- Listing 8.9 Using multiple spatial reference ids
CREATE TABLE world.city_buffers(city varchar(150) PRIMARY KEY,         
    the_geom geometry,                                                 --#1
    the_geog geography(POLYGON,4326));                                 --#1
INSERT INTO world.city_buffers(city, the_geom)                         --#2
SELECT DISTINCT ON (c.name) c.name,                                    --#2
   ST_Buffer(ST_Transform(the_geom,                                    --#2
        utmzone(c.the_geom)), 10) As the_geom                          --#2
FROM world.cities As c;                                                --#2

UPDATE world.city_buffers                                              --#3
  SET the_geog = geography(ST_Transform(the_geom, 4326));
--#1 geometry, geography
--#2 populate geometry
--#3 update geography



-- Listing 8.10 Compare areas of 10 meter utm radius buffers around cities
SELECT city, CAST(utm As integer) As utm_sm, 
CAST(geog As integer) As geog_sm, 
	CAST(wm As integer) As wm_sm, 
	CAST(abs(c.utm - c.geog) As numeric(10,2) )  As diff_utm_g,
	CAST(abs(c.utm - c.wm) As numeric(10,2) )  As diff_utm_wm
FROM (
SELECT city, ST_Area(the_geom) As utm, 
	ST_Area(the_geog) As geog, 
	ST_Area(ST_Transform(the_geom, 3785)) As wm
FROM world.city_buffers) As c
WHERE abs(c.utm - c.wm) < 0.2 or abs(c.utm - c.wm) > 900 or city IN('Boston','Honolulu', 'Paris', 'San Francisco')
ORDER BY  abs(c.utm - c.wm);


-- Listing 8.11 Create dummy observation data
CREATE TABLE us.observations (                                         --#1
    obsid serial PRIMARY KEY, 
    obs_name varchar(50),
    obs_date date, 
    state_fips varchar(2), 
    state varchar(20));
SELECT                                                                 --#2
  AddGeometryColumn('us','observations','the_geom','4326','POINT','2');

INSERT INTO us.observations(obs_name, obs_date, the_geom)              --#3
SELECT a.obs_name, 
    DATE '2008-01-01' + CAST( 
       CAST (random()*1000 As text) || ' days' As interval ),
    ST_SetSRID(ST_Point(-170 + random()*200, 17 
        + random()*50),4326) As the_geom
FROM unnest(ARRAY['parrot', 'parakeet', 'dove', 'pigeon', 'lizard monster', 
  'eagle', 'cat eater bird']) As a(obs_name)
    CROSS JOIN generate_series(1,2000, 1) As i;

INSERT INTO us.observations(obs_name, obs_date, the_geom)             --#4
SELECT a.obs_name, DATE '2008-01-01' 
       + CAST(CAST (random()*1000 As text)    || ' days' As interval), 
    ST_SetSRID(
      ST_Point(-100 + random()*30, 30 + random()*20),4326) As the_geom
FROM unnest(
 ARRAY['dinoparrot', 'platibird', 'dove', 'pigeon', 
   'lizard monster', 'eagle', 'cat eater bird']) As a(obs_name)
CROSS JOIN generate_series(1,4000, 1) As i;

DELETE FROM us.observations                                           --#5
WHERE NOT EXISTS (SELECT s.gid FROM us.states AS s
        WHERE ST_Intersects(s.the_geom, ST_Transform(us.observations.the_geom,2163)) ) ;

--#1 create observation table
-- #2 add point field
-- #3 create random observations
--#4 add more to shift weight
-- #5 remove unrealistic observations

-- Section 8.2.2 Tag data to a specific region
--Tag points with a region
UPDATE us.observations 
    SET state = s.state, state_fips = s.state_fips
FROM us.states As s
WHERE ST_Intersects(s.the_geom, 
  ST_Transform(us. observations.the_geom,2163));


-- 8.2.3	Snapping points to closest linestring

-- Listing 8.12 Query to snap points to linestrings � version 1
SELECT  pt_id, ln_id,
  ST_Line_Interpolate_Point(ln_geom,
   ST_Line_Locate_Point(ln_geom, pt_geom)                             --#1
 ) As snapped_point
FROM
(SELECT DISTINCT ON (pt.gid)                                          --#2
     ln.the_geom AS ln_geom,                                            
     pt.the_geom AS pt_geom, ln.gid AS ln_id, pt.gid AS pt_id
FROM
    ch08.sites AS pt INNER JOIN
    ch08.roads AS ln 
ON
    ST_DWithin(pt.the_geom, ln.the_geom, 10.0)                        --#3
ORDER BY
    pt.gid,ST_Distance(ln.the_geom, pt.the_geom)                      --#4
) AS subquery;                                                        --#5
--#1 closest point on line to point
--#2 return point once
--#3 limit search 10 units
--#4 linestring closest to each point 
--#5 alias as subquery


-- Listing 8.13 Query to snap points to linestring without subquery � version 2
SELECT DISTINCT ON (pt.id)
 ln.the_geom AS ln_geom,
 pt.the_geom AS pt_geom,
 ln.id AS ln_id,
 pt.id AS pt_id, 
 ST_Line_Interpolate_Point(
     ln.the_geom,
     ST_Line_Locate_Point(ln.the_geom, pt.the_geom)
     ) As snapped_point
FROM
point_table AS pt INNER JOIN
line_table AS ln
  ON
   ST_DWithin(pt.the_geom, ln.the_geom, 10.0)
ORDER BY
  pt.id,ST_Distance(ln.the_geom, pt.the_geom);



-- Listing 8.14 Geocode an address to a point
CREATE TABLE sf.test_addresses(gid SERIAL PRIMARY KEY,             --#1
    st_num integer, st_name varchar(150), zipcode char(5),
    st_pos char(1), the_geom geometry);
INSERT INTO sf.test_addresses(st_num,st_name,zipcode)
    VALUES
        ( 33, 'NEW MONTGOMERY ST', '94105' ),
        ( 250, 'CALIFORNIA AVE', '94130' ),
        ( 360, 'ROOSEVELT WAY', '94114' )
    ;
UPDATE sf.test_addresses
    SET  
        st_pos = CASE WHEN MOD(sc.lf_fadd,2) =                     --#2
                 MOD(sf.test_addresses.st_num,2)
            THEN 'L'
        ELSE 'R'
        END,
        the_geom = ST_Line_Interpolate_Point(                      --#3 
            ST_LineMerge(sc.the_geom),
            ( sf.test_addresses.st_num 
                  - least(sc.lf_fadd, sc.rt_fadd) )
            / ( greatest (sc.lf_toadd, sc.rt_toadd) 
                - least (sc.lf_fadd, sc.rt_fadd) )
            )
    FROM sf.stclines_streets AS sc
    WHERE                                                          --#4
      substring(sc.zip_code,1,5) = sf.test_addresses.zipcode AND
      sc.streetname = sf.test_addresses.st_name AND
      (sf.test_addresses.st_num BETWEEN sc.lf_fadd AND sc.lf_toadd
       OR sf.test_addresses.st_num BETWEEN sc.rt_fadd AND sc.rt_toadd);

-- #1 create test data
-- #2 left or right
-- #3 point on street
-- #4 locate street

	
-- Listing 8.15 Create line path from point observations
SELECT t.track_period, MIN(time) As t_start,                          --#1
    Max(time) As t_end, 
    ST_MakeLine(the_geom) As the_geom
INTO ch08.aussie_run 
FROM (
    SELECT p.time, p.the_geom, 
        DATE_TRUNC('minute', p.time)                                  --#2 
        - CAST(
          MOD(CAST(DATE_PART('minute', p.time) As integer),15) ||
                        ' minutes' As interval) As track_period
    FROM ch08.aussie_track_points As p
    ORDER BY (DATE_TRUNC('minute', p.time)                            --#2 
        - CAST(
          MOD(CAST(DATE_PART('minute', p.time) As integer),15) ||
                        ' minutes' As interval) ) , p.time) As t      --#3
GROUP BY 
    t.track_period                                                    --#4
HAVING COUNT(time) > 2
ORDER BY t.track_period;

SELECT CAST(track_period As timestamp),                           --#5 BEG
   CAST(t_start As timestamp) As t_start,                             
   CAST(t_end As timestamp) As t_end, 
   ST_NPoints(the_geom) As np, 
   CAST(ST_Length_Spheroid(the_geom, 
     CAST('SPHEROID["WGS_1984",6378137,298.257223563]' 
             As spheroid)
        ) As integer) As  dist_m, (t_end - t_start) As dur
 FROM ch08.aussie_run;                                            --#5 END

--#1 return columns
--#2 snap time to closest track period
--#3 order by track period
--#4 group by track period
--#5 calculate length, time per period 


 
-- Listing 8.16 Make two point lines from linestrings
SELECT ogc_fid, n As pt_id,                                          --#1
    ST_MakeLine(
    ST_PointN(the_geom,n), 
    ST_PointN(the_geom,n + 1) 
) As the_geom
FROM ch08.aussie_tracks
    CROSS JOIN generate_series(1,10000) As n                         --#2
WHERE n < ST_NPoints(the_geom)                                       --#3
ORDER by ogc_fid, pt_id;
-- #1 non-aggregate ST_MakeLine
-- #2 generate_series as iterator
-- #3 limit iterator


-- Listing 8.17  Make two point lines from Multilinestrings or Linestrings
SELECT ogc_fid, n As pt_id,(sl.g).path[1] As nline,                    --#1
    ST_MakeLine(
    ST_PointN((sl.g).geom,n), 
    ST_PointN((sl.g).geom,n + 1) 
) As the_geom
FROM (SELECT ogc_fid, ST_Dump(the_geom) As g                           --#2
FROM ch08.aussie_tracks) As sl                                         --#2
    CROSS JOIN generate_series(1,10000) As n
WHERE n < ST_NPoints((sl.g).geom)                                      --#3
ORDER by ogc_fid, nline, pt_id;




-- Listing 8.18 Function to cut linestring at point junctions
CREATE OR REPLACE FUNCTION upgis_cutlineatpoints(param_mlgeom geometry, 
                param_mpgeom geometry, 
param_tol double precision)
  RETURNS geometry AS
$$
  DECLARE 
    var_resultgeom geometry;
    -- dump out multis into single points 
    -- and lines so we can use line ref functions
    var_pset geometry[] :=                                             --#1
           ARRAY(SELECT geom FROM ST_Dump(param_mpgeom));              --#1
    var_lset geometry[] := ARRAY(SELECT geom                           --#1
                          FROM ST_Dump(param_mlgeom));                 --#1
    var_sline geometry;
    var_eline geometry;
    var_perc_line double precision;
    var_refgeom geometry;
    
  BEGIN
  FOR i in 1 .. array_upper(var_pset,1)                                --#2
    LOOP
      -- Loop thru the linestrings
      FOR j in 1 .. array_upper(var_lset,1)
        LOOP
        -- Check the distance and update if within tolerance
        IF ST_DWithin(var_lset[j],var_pset[i], param_tol) 
                AND NOT ST_Intersects(ST_Boundary(var_lset[j]), var_pset[i]) THEN
          IF ST_NumGeometries(ST_Multi(var_lset[j]) ) = 1   THEN
            --get percent along line point is
            var_perc_line := ST_Line_Locate_Point(
                var_lset[j], var_pset[i]);

                IF var_perc_line BETWEEN 0.0001 and 0.9999 THEN
            --get first cut only cut if not too close to edge
            var_sline := ST_Line_Substring(var_lset[j],0, var_perc_line);
            -- get secont cut
            var_eline := ST_Line_Substring(var_lset[j],var_perc_line, 1);
            --fix rounding so start line abutts second cut
            var_eline := ST_SetPoint(var_eline, 0, ST_EndPoint(var_sline));

            -- collect the two parts together 
            
            var_lset[j] := ST_Collect(var_sline, var_eline);      --#3

         END IF;
          ELSE 
            var_lset[j] :=                                       --#4
                upgis_cutlineatpoints(var_lset[j], var_pset[i]);
          END IF;
        END IF;
      END LOOP;
    END LOOP;

  RETURN ST_Union(var_lset);

  END;
$$
  LANGUAGE 'plpgsql' IMMUTABLE STRICT;
--#1 explode geometries
--#2 loop through points 
--#3 create a multilinestring cut
--#4 recursively cut

-- using the function
SELECT gid, the_geom As orig_geom, 
    upgis_cutlineatpoints(the_geom, foo.the_pt, 100 ) As changed
FROM sf.stclines_streets AS s CROSS JOIN 
    (SELECT ST_SetSRID(ST_Point(6011200, 2113500),2227) As the_pt) As foo
WHERE ST_DWithin(s.the_geom, foo.the_pt, 100);

-- Listing 8.19 Analysis pre-dissolving records
SELECT city, COUNT(city) As num_records, 
    SUM(
        ST_Numgeometries(the_geom)
        ) As numpolygons_before, 
    ST_Numgeometries(
        ST_Multi(ST_Union(the_geom))
        ) As num_polygons_afte 
FROM sf.cities
GROUP BY city
HAVING COUNT(city) > 1;


-- Listing 8.20 Create one record per city
SELECT city, ST_Multi(ST_Union(the_geom)) As the_geom                  --#1
INTO sf.distinct_cities
FROM sf.cities  GROUP BY city;

SELECT populate_geometry_columns('sf.distinct_cities'::regclass);      --#2
ALTER TABLE sf.distinct_cities ADD CONSTRAINT pk_distinct_cities       --#3
    PRIMARY KEY(city); 
CREATE INDEX idx_distinct_cities_the_geom ON                           --#4
    sf.distinct_cities USING gist(the_geom);
--#1 bulk create table
--#2 register table in geometry_columns
--#3 primary key
--#4 spatial index

	
Listing 8.21 Divide US into quadrants
WITH usext AS
(
 SELECT ST_SetSRID(                                                --#A BEG
    CAST(ST_Extent(the_geom) As geometry),2163) As the_geom_ext, 
    60 as x_gridcnt, 40 as y_gridcnt
 FROM us.states As s
  ),                                                               --#A END
grid_dim AS                                                        --#B BEG
 (SELECT (
    ST_XMax(the_geom_ext) - ST_XMin(the_geom_ext)
    )/x_gridcnt As g_width,
        ST_XMin(the_geom_ext) As xmin, 
        ST_xmax(the_geom_ext) As xmax,
    (
        ST_YMax(the_geom_ext) - ST_YMin(the_geom_ext)
    )/y_gridcnt As g_height,
        ST_YMin(the_geom_ext) As ymin, 
        ST_YMax(the_geom_ext) As ymax
    FROM usext
    ),                                                             --#B END

grid As (                                                          --#C BEG
   SELECT x,y,
    ST_SetSRID(ST_MakeBox2d(
        ST_Point(xmin + (x - 1)*g_width, ymin + (y-1)*g_height),
        ST_Point(xmin + x*g_width, ymin + y*g_height)
        )
        ,2163) As grid_geom
FROM (SELECT generate_series(1,x_gridcnt) FROM usext) As x(x)
    CROSS JOIN (SELECT generate_series(1,y_gridcnt) FROM usext) As y(y) CROSS JOIN grid_dim
)                                                                  --#C END
SELECT grid.x, grid.y, state, state_fips,                          --#D BEG
    ST_Intersection(s.the_geom, grid_geom) As the_geom
    INTO us.grid_throwaway
    FROM us.states As s
   INNER JOIN grid 
      ON (ST_Intersects(s.the_geom, grid.grid_geom));  --#D END

    CREATE INDEX idx_us_grid_throwaway_the_geom        --#E
        ON us.grid_throwaway USING gist(the_geom);
-- #A define constants
-- #B create a painting tile
-- #C divide extent into rectangles
-- #D cut grid by state boundary
-- #E index

-- Listing 8.22 Bisect state of Idaho
WITH RECURSIVE 
  ref(the_geom, env) AS (                                          --#1 BEG
       SELECT  the_geom, 
        ST_Envelope(the_geom) As env, 
        ST_Area(The_geom)/2 As targ_area,
        1000 As nit
        FROM us.states 
       WHERE state = 'Idaho'
   ),                                                              --#1 END
  T(n,overlap) AS (                                                --#2 BEG
    VALUES (CAST(0 As Float),CAST(0 As Float))
    UNION ALL
    SELECT n + nit, 
       ST_Area(ST_Intersection(the_geom, 
           ST_Translate(env, n+nit, 0))) 
    FROM T CROSS JOIN ref 
    WHERE ST_Area(
           ST_Intersection(the_geom, ST_Translate(env, n+nit, 0))) 
    > ref.targ_area
) ,                                                               --#2 END
bi(n) AS                                                          --#3 BEG
 (SELECT n    
    FROM T
    ORDER BY n DESC LIMIT 1)                                      --#3 END
SELECT bi.n,                                                      --#4 BEG
    ST_Difference(the_geom, 
      ST_Translate(ref.env, n,0)) As geom_part1,  
      ST_Intersection(the_geom, 
          ST_Translate(ref.env, n,0)) As geom_part2
FROM bi CROSS JOIN ref;                                           --#4 END
--#1 state variables
--#2 recursive iterator
--#3 cte returns how far in x dir to cut
--#4 return both parts of idaho

-- Listing 8.23 upgis_slicegeometry � cuts a geometry into equal areas
CREATE OR REPLACE FUNCTION utility.upgis_slicegeometry(ageom geometry ,numsections integer, OUT bucket integer, OUT the_geom geometry) 
RETURNS SETOF record AS 
$$
WITH RECURSIVE                                                    --#1 Beg

    ref(the_geom, the_box, targ_area, x_mov, y_mov,
        x_length, y_length, xmin, ymin) AS (
        SELECT the_geom, 
        ST_SetSRID(ST_MakeBox2D(ST_Point(xmin, ymin), 
            ST_Point(xmin + CAST(x_length/ngrid_xy As integer), 
            ymin + CAST(y_length/ngrid_xy As integer)
            ) 
        ),
        ST_SRID(s.the_geom) ) As the_box, 
            ST_Area(the_geom)/$2 As targ_area, 
            CAST(x_length/ngrid_xy As integer) As x_mov,
            CAST(y_length/ngrid_xy As integer) y_mov,
            s.x_length, 
            s.y_length,  xmin, ymin
        FROM (SELECT $1 As the_geom, 
        ST_XMin($1) As xmin,
        ST_YMin($1) As ymin,
        ST_XMax($1) - ST_XMin($1) As x_length,
        ST_YMax($1) - ST_YMin($1) As y_length, 15*$2 As ngrid_xy
         
    ) As s
),                                                               --#1 End
X(x) As (VALUES (CAST(0 As float))                               --#2 Beg
        UNION ALL
        SELECT x + ref.x_mov 
           FROM X CROSS JOIN ref 
             WHERE x < ref.x_length),
    Y(y) As (VALUES (CAST(0 As float))
        UNION ALL
        SELECT y + ref.y_mov FROM Y 
            CROSS JOIN ref WHERE y < ref.y_length),              --#2 End
     diced AS                                           --#3 Beg
     (SELECT  ROW_NUMBER() 
         OVER(ORDER BY x,y ) As row_num
    , g.x, g.y,  g.the_geom
    FROM 
    (SELECT x, y, 
        ST_Intersection(
            ref.the_geom, 
            ST_Translate(ref.the_box, x, y)
        ) As the_geom
            FROM x CROSS JOIN y  CROSS JOIN ref 
        
    WHERE ST_Intersects(ref.the_geom, 
        ST_Translate(ref.the_box, x, y)
        )
    ) As g
    ),                                                  --#3 End
    T(bucket, row_num, the_geom, total_area,            --#4 Beg
         targ_area, remaining_area) AS (
    SELECT 1 As bucket, 
row_num, 
diced.the_geom, 
ST_Area(diced.the_geom) As total_area, 
ref.targ_area, 
        ST_Area(ref.the_geom) 
          - ST_Area(diced.the_geom) As remaining_area
        FROM diced CROSS JOIN ref WHERE diced.row_num = 1
    UNION ALL 
        SELECT CASE WHEN (T2.total_area 
           + ST_Area(diced.the_geom) < T2.targ_area 
                OR T2.remaining_area < T2.targ_area/4) 
        THEN T2.bucket 
ELSE T2.bucket + 1 END As bucket, 
diced.row_num, diced.the_geom,
        CASE WHEN ( T2.total_area 
          + ST_Area(diced.the_geom) ) < T2.targ_area 
        THEN T2.total_area + ST_Area(diced.the_geom) 
        ELSE ST_Area(diced.the_geom) END As total_area,
        T2.targ_area, T2.remaining_area 
          - ST_Area(diced.the_geom) As remaining_area
    FROM diced INNER JOIN (SELECT * 
        FROM T ORDER BY row_num DESC LIMIT 1) As T2 
    ON diced.row_num = T2.row_num + 1
        )                                               --#4 End
   SELECT bucket, ST_Union(the_geom) As the_geom        --#5
    FROM T                                              --#5
    GROUP BY T.bucket, T.targ_area                      --#5

$$
LANGUAGE 'sql' IMMUTABLE;
-- #1 define constants
-- #2 start positions squares
-- #3 window translate dice
-- #4 bucket shards
-- #5 union buckets

-- example use
-- this is code that will work once you install a function later described
SELECT bucket, the_geom, ST_Area(the_geom) As the_area
FROM utility.upgis_slicegeometry(
    (SELECT the_geom FROM us.states 
            WHERE state = 'Oklahoma'), 4) As foo;
-- end example

-- Listing 8.24 Generate a Rectangle and a Hexagonal Grid centered in USA
WITH center_point(x,y) AS                                         --#1
(                                                                 --#1
   SELECT -288499, -2718                                          --#1
),                                                                --#1
paintbrush(the_hex, the_rect) AS                                  --#2 Beg
(
SELECT ST_SetSRID(ST_Translate(
        ST_GeomFromText('POLYGON((0 0,64 64,64 128,0 192,
         -64 128,-64 64,0 0))'), x, y), 2163) As the_hex,
ST_SetSRID(ST_Translate(CAST(ST_MakeBox2D(ST_Point(-64,0), 
            ST_Point(64,192) ) As geometry), 
                x, y), 2163) As the_rect
FROM center_point
)                                                                 --#2 End
SELECT xf.x, yf.y,                                                --#3 Beg
   ST_Translate(paintbrush.the_hex, xf.x_hex, yf.y_hex) As hex_tile, 
   ST_Translate(paintbrush.the_rect, 
      xf.x_rect,yf.y_rect) As rect_tile
FROM (SELECT x, x*(ST_XMax(the_hex) - ST_XMin(the_hex)) As x_hex,
x*(ST_XMax(the_rect) - ST_XMin(the_rect)) As x_rect
FROM
generate_series(-50, 50) As x CROSS JOIN paintbrush) As xf
 CROSS JOIN (SELECT y, y*(ST_YMax(the_hex) - ST_YMin(the_hex)) As y_hex,
y*(ST_YMax(the_rect) - ST_YMin(the_rect)) As y_rect
FROM
generate_series(-50, 50) As y CROSS JOIN paintbrush) As yf
CROSS JOIN paintbrush;                                             --#3 End
--#1 cte center_point
--#2 cte hex/square dual paintbrush
--#3 start from center paint

-- Listing 8.25 Example scaling a hexagon to different sizes
SELECT xfactor, yfactor, ST_Scale(hex.the_geom, xfactor, yfactor) As 
     scaled_geometry   
FROM 
( SELECT                                                           --#1 Beg
ST_GeomFromText('POLYGON((0 0,64 64,64 128,0 192,                      
        -64 128,-64 64,0 0))') As the_geom)                            
 As hex                                                            --#1 End
  CROSS JOIN (SELECT x*0.5 As xfactor                                  --#2
         FROM generate_series(1,4) As x) As xf                         --#2
CROSS JOIN (SELECT y*0.5 As yfactor                                    --#2
     FROM generate_series(1,4) As y) As yf;                            --#2

--#1 hex to scale
--#2 scaling values

-- Listing 8.26 Combining Scale and Translation to maintain centroid
SELECT xfactor, yfactor, 
   ST_Translate(ST_Scale(hex.the_geom, xfactor, yfactor), 
     ST_X(ST_Centroid(the_geom))*(1 - xfactor), 
     ST_Y(ST_Centroid(the_geom))*(1 - yfactor) ) As scaled_geometry
FROM 
( SELECT ST_GeomFromText('POLYGON((0 0,64 64,64 128,0 192,-64 128,
    -64 64,0 0))') As the_geom)  As hex
CROSS JOIN (SELECT x*0.5 As xfactor 
         FROM generate_series(1,4) As x) As xf
CROSS JOIN (SELECT y*0.5 As yfactor
     FROM generate_series(1,4) As y) As yf;
     
     
-- Listing 8.27 Example of ST_Rotate rotating a hexagon from 0 to 270 degrees
SELECT rotrad/pi()*180 As deg, 
    ST_Rotate(hex.the_geom,rotrad)   As rotated_geometry
FROM 
( SELECT ST_GeomFromText('POLYGON((0 0,64 64,64 128,0 192,
      -64 128,-64 64,0 0))') As the_geom)   As hex
CROSS JOIN (SELECT 2*pi()*x*45.0/360 As rotrad
         FROM generate_series(0,6) As x) As xf;

-- Listing 8.28 Example of ST_Rotate in combination with ST_Translate to rotate about centroid
CREATE OR REPLACE FUNCTION RotateAtPoint(the_geom geometry,        --#1 Beg
    pt_x double precision, pt_y double precision, 
        rotrads double precision)
 RETURNS geometry AS 
$$
SELECT ST_Translate(ST_Rotate(
         ST_Translate($1,-1*$2,-1*$3),$4),$2,$3)
$$
   LANGUAGE 'sql';                                                 --#1 End

SELECT rotrad/pi()*180 As deg,                                     --#2 Beg
     RotateAtPoint(hex.the_geom,ST_X(ST_Centroid(hex.the_geom)),    
       ST_Y(ST_Centroid(hex.the_geom)), rotrad) As rotated_geometry
FROM 
( SELECT ST_GeomFromText('POLYGON((0 0,64 64,64 128,0 192,
       -64 128,-64 64,0 0))') As the_geom)
 As hex
CROSS JOIN (SELECT 2*pi()*x*45.0/360 As rotrad
         FROM generate_series(0,1) As x) As xf;                    --#2 End
--#1 RotateAtPoint function
--#2 rotate hexagon about centroid
