In order to run the exercises in Chapter 8, you need to load the datasets 
in the data folder.  You can use psql or PgAdmin III to do so.

The datasets are broken into the separate schemas and can be found in the data folder.

using psql:

1) sf_data.sql consists of sample data from San Francisco Bay Area that was downloaded from http://datasf.org/

-- you can load it with this command which will create the schema and load the data
psql -h localhost -U postgres -d postgis_in_action -p 5432 -f sf_data.sql


Datasets included used are: http://gispub02.sfgov.org/website/sfshare/catalog/bayarea_bridges.zip (sf.bridges)
http://gispub02.sfgov.org/website/sfshare/catalog/bayarea_cities.zip (sf.cities)
http://gispub02.sfgov.org/website/sfshare/catalog/stclines_streets.zip (sf.streets)

2) us.states.sql (this was from http://www2.census.gov/geo/tiger/TIGER2009/tl_2009_us_state.zip  transformed to US National Atlas - SRID: 2163)
-- you can load it with this command which will create the schema and load the data
psql -h localhost -U postgres -d postgis_in_action -p 5432 -f us.states.sql


3) world_data.sql consists of cities table of long lat point geometries of major world cities