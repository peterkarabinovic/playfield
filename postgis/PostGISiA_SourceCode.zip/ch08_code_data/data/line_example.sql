﻿SELECT gid As id, street, the_geom INTO ch08.line_table from sf.stclines_streets

WHERE street IN( 'DIAMOND','MOFFITT', 'PORTOLA', 'BENTON', 'NOE', 'MARKET','EUGENIA')

drop table ch08.line_table;

delete from ch08.line_table where id between 3207 and 3213 or id IN(3111,3212, 3213,11092);

SELECT ROW_NUMBER() OVER() As id, ST_SetSRID(ST_Point(6002776 + x*random()*2000,2106671 + y*random()*2000),2227) As the_geom
INTO ch08.point_table
FROM generate_series(-10,5) As x cross join generate_series(-8,20) As y;

DELETE FROM ch08.point_table WHERE NOT EXists(SELECT id FROM ch08.line_table As l WHERE ST_DWithin(l.the_geom, ch08.point_table.the_geom, 2000) );

DELETE FROM ch08.point_table WHERE EXists(SELECT id FROM ch08.line_table As l WHERE ST_DWithin(l.the_geom, ch08.point_table.the_geom, 500) );

DELETE FROM ch08.point_table WHERE EXists(SELECT id FROM ch08.point_table As l WHERE l.id <> ch08.point_table.id AND ST_DWithin(l.the_geom, ch08.point_table.the_geom, 1000) );

SELECT ST_SRID(the_geom) from ch08.line_table;

SELECT ST_AsText(ST_Centroid(ST_EXtent(the_geom))) from ch08.line_table

drop table ch08.point_table;

UPDATE ch08.line_table SET the_geom = ST_LineMerge(the_geom);

set search_path=ch08,public;
SELECT DISTINCT ON (pt.id)
 ln.the_geom AS ln_geom,
 ST_AsBinary(pt.the_geom) AS pt_geom,
 ln.id AS ln_id,
 pt.id AS pt_id, 
 ST_ASBinary(ST_Line_Interpolate_Point(
     ln.the_geom,
     ST_Line_Locate_Point(ln.the_geom, pt.the_geom)
     )) As snapped_point
FROM
ch08.point_table AS pt INNER JOIN
ch08.line_table AS ln
  ON
   ST_DWithin(pt.the_geom, ln.the_geom, 10*1024)
ORDER BY
  pt.id,ST_Distance(ln.the_geom, pt.the_geom);


DELETE FROM ch08.point_table where id IN(90,176,262)