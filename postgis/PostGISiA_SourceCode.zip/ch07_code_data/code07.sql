--Listing 7.1
SELECT array_to_string(ARRAY(SELECT 'ALTER TABLE ' || c.table_schema || '.'
	|| c.table_name || ' RENAME "' || c.column_name || '" TO ' || lower(c.column_name)
	FROM information_schema.columns c
	WHERE c.column_name <> lower(c.column_name) AND
		c.table_schema = 'staging'
		AND c.table_name IN('statesp020', 'world')) , ';' || E'\r') As ddlsql;

-- Listing 7.2
CREATE SCHEMA us; -- for holding US centric data
CREATE SCHEMA canada; -- for holding canada centric data
CREATE SCHEMA staging; -- this is a schema to hold temporary data
ALTER DATABASE postgis_in_action SET search_path=public,"$user",us,canada;

-- Listing 7.3
-- 1 create new table to hold states
CREATE TABLE us.states
(
  gid serial NOT NULL,
  state character varying(20),
  state_fips character varying(2),
  order_adm integer,
  month_adm character varying(18),
  day_adm integer,
  year_adm integer
);

-- 2 Create a new geometry column with constraints for national atlas equal area polygon
SELECT AddGeometryColumn ('us','states','the_geom',2163,'MULTIPOLYGON',2);

INSERT INTO us.states(state, state_fips, order_adm, month_adm, year_adm, the_geom)
SELECT state, state_fips, order_adm, month_adm, year_adm,
	-- 3 convert polygons to multipolygons
	ST_Multi(
	-- 4 Simplify our geometry note we do this last (simplifying in planar doesn't work to well
		ST_SimplifyPreserveTopology(
	-- 5 Dissolve boundaries across all records for same state and union into single multipolygon so we have 1 per state
		ST_Union(
		-- 6 Transform from NAD 83 long lat to US National Atlas Equal area meters
			ST_Transform(the_geom_4269, 2163)
			)
	,
	-- 7 Since we are transforming data in 2163 space (meters) the 700 is meters -- it is the input to simplify and basically means try to make the distance between each polygon vertex at most 700 meters
			700
		)
	) As the_geom
FROM staging.statesp020
-- 8 This ensures we have at most one record per this combo (so we will go from 2895 records down to 53 records in 22 seconds with PostGIS 1.4+)
GROUP BY state, state_fips, order_adm, month_adm, year_adm;



-- Listing 7.4 Putting in indexing and preparation for querying
-- 1 
CREATE INDEX idx_us_states_the_geom ON us.states USING gist (the_geom);

-- 2 
ALTER TABLE us.states
  ADD CONSTRAINT pkey_us_states_state_fips PRIMARY KEY(state_fips);

-- 3 
CREATE UNIQUE INDEX uidx_us_states_gid
   ON us.states USING btree (gid);

CREATE UNIQUE INDEX uidx_us_states_state
   ON us.states USING btree (state);

-- 4 
VACUUM ANALYZE us.states;

-- 5 
SELECT DropGeometryTable('staging', 'statesp020');
-- 1 spatial index
-- 2 primary key
-- 3 unique keys
-- 4 purge dead rows
-- 5 drop temp table
