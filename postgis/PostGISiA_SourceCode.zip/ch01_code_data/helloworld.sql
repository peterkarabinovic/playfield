CREATE SCHEMA hello;
CREATE TABLE hello.poi(poi_id serial PRIMARY KEY, poi_name varchar(150));
--This will create a geometry field in hello.poi 
-- called poi_geom with constraint enforcing 
-- only 2 dimensional points can be added
SELECT AddGeometryColumn ('hello','poi','poi_geom',-1,'POINT',2);
INSERT INTO hello.poi(poi_name, poi_geom)
	VALUES ('Hospital', ST_Point(3436, 34972)), 
		('Restaurant', ST_Point(56783,10386)), 
		('College',ST_Point(50100,42330)),
		('Park', ST_Point(82027, 55755)),
		('Zoo', ST_Point(84178, 46488));
--Now we create our fake coastlines
CREATE TABLE hello.coastline(coastline_id serial PRIMARY KEY, coastline_name varchar(150));
SELECT AddGeometryColumn ('hello','coastline','line_geom',-1,'LINESTRING',2);


INSERT INTO hello.coastline(coastline_name, line_geom)
VALUES ('The Hello Coastline', 
ST_GeomFromText('LINESTRING (1144 2044, -2528 11912, -3270.50 25008, -323 35209, 9198 44504, 15319 45412, 42224.25 59878, 41070 77217)') );

-- We index our table so our query speeds 
-- will remain responsive as our world perimeter expands
CREATE INDEX idx_hello_poi_poi_geom
   ON hello.poi USING gist(poi_geom);

CREATE INDEX idx_hello_poi_poi_name
   ON hello.poi USING btree(upper(poi_name));

CREATE INDEX idx_hello_coastline_line_geom
   ON hello.coastline USING gist(line_geom);

CREATE INDEX idx_hello_coastline_name
   ON hello.coastline USING btree(upper(coastline_name));

--And then we vacuum analyze which forces immediate rebuild of query stats
--This step is particular important to do when you do massive bulk uploads

vacuum analyze hello.poi;
vacuum analyze hello.coastline;


--Points of interest in danger
SELECT p.poi_name, 
round(CAST(ST_Distance(p.poi_geom, c.line_geom) / 1000 
 As numeric),2) As dist_meters
FROM hello.poi As p 
	INNER JOIN hello.coastline As c ON ST_DWithin(c.line_geom, p.poi_geom, 1000*3);

--The extent of Hello
SELECT ST_Area(foo.helloextent)/(609.344*609.344) As ext_sqmiles, 
		(ST_XMax(foo.helloextent) - ST_XMin(foo.helloextent))/609.344 As ext_widthmiles,
		(ST_YMax(foo.helloextent) - ST_YMin(foo.helloextent))/609.344 As ext_heightmiles
   FROM 
(SELECT ST_Extent(poi_geom) As helloextent
   		FROM hello.poi) As foo;



