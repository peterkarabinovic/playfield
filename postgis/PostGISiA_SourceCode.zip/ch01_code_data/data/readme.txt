http://www.nationalatlas.gov/atlasftp.html#roadtrl

The fastfoods dataset was provided by courtesy of Ian Spiro -- owner of http://www.fastfoodmaps.com/