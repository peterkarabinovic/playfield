﻿SET search_path=pizza,public;
CREATE TABLE pizza_lovers(pl_id serial primary key,incbrack char(1));
SELECT AddGeometryColumn ('pizza','pizza_lovers','the_geom',2163,'POINT',2);
SET search_path=pizza,public;
INSERT INTO pizza_lovers(the_geom, incbrack)
SELECT the_geom, 'M' As incbrack
FROM (SELECT 
            ST_Transform(
                ST_SetSRID(
                    ST_MakePoint(-71 + x*random()*0.2,42 + y*0.2*random()),4326),2163) As the_geom,
            x*y As fakepop
        FROM generate_series(100,200,5) x 
            CROSS JOIN generate_series(1,40) y
        ) As foo;


INSERT INTO pizza_lovers(the_geom, incbrack)
SELECT the_geom, 'L' As incbrack
FROM (SELECT 
            ST_Transform(
                ST_SetSRID(
                    ST_MakePoint(-71 + x*random()*0.2,42 + y*0.2*random()),4326),2163) As the_geom,
            x*y As fakepop
        FROM generate_series(100,200,5) x 
            CROSS JOIN generate_series(1,40) y
        ) As foo;


INSERT INTO pizza_lovers(the_geom, incbrack)
SELECT the_geom, 'H' As incbrack
FROM (SELECT 
            ST_Transform(
                ST_SetSRID(
                    ST_MakePoint(-71 + x*random()*0.2,42 + y*0.2*random()),4326),2163) As the_geom,
            x*y As fakepop
        FROM generate_series(100,200,5) x 
            CROSS JOIN generate_series(1,40) y
        ) As foo;
SET search_path=pizza,public;
CREATE TABLE pizza_stores(ps_id serial primary key, style varchar(50));
SELECT AddGeometryColumn ('pizza','pizza_stores','the_geom',2163,'POINT',2);
truncate table pizza_stores;
INSERT INTO pizza_stores(the_geom, style)
SELECT the_geom, 'Gourmet' As incbrack
FROM (SELECT 
            ST_Transform(
                ST_SetSRID(
                    ST_MakePoint(-71 + x*random()*0.2,42 + y*0.2*random()),4326),2163) As the_geom,
            x*y As fakepop
        FROM generate_series(100,200,45) x 
            CROSS JOIN generate_series(1,40,15) y
        ) As foo;

INSERT INTO pizza_stores(the_geom, style)
SELECT the_geom, 'Regular' As incbrack
FROM (SELECT 
            ST_Transform(
                ST_SetSRID(
                    ST_MakePoint(-71 + x*random()*0.2,42 + y*0.2*random()),4326),2163) As the_geom,
            x*y As fakepop
        FROM generate_series(100,200,35) x 
            CROSS JOIN generate_series(1,40,13) y
        ) As foo;
SET search_path=pizza,public;
--truncate table pizza.pizza_regions;
CREATE TABLE pizza_regions(pr_id serial PRIMARY KEY, region_name varchar);
SELECT AddGeometryColumn ('pizza','pizza_regions','the_geom', 2163,'POLYGON',2);
INSERT INTO pizza.pizza_regions(region_name, the_geom)
	VALUES ('Region A', ST_GeomFromText('POLYGON ((3349020 1481080, 3023700 1324920, 3418698 1030851, 3747520 1198060, 3757280 1456680, 3627645.774977529 1564323, 3349020 1481080))', 2163)), ('Region B', ST_GeomFromText('POLYGON ((3023700 1324920, 3418698 1030851, 3434641 925713, 3106202 819197, 3002560 893900, 2990424 859575, 3023700 1324920))', 2163)),
('Region C', ST_GeomFromText('POLYGON ((3106202 819197, 3150286 624328, 3352409 669201, 3533015 729314, 3683028 866431, 3746714 933016, 3825498 999362, 3747520 1198060, 3418698 1030851, 3434641 925713, 3427530 923407, 3106202 819197))',2163));
