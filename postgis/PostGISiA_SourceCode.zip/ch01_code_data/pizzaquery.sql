SELECT r.region_name, COUNT(pl.pl_id) As totpop, AVG(pl.min_dist)/1000 As average_dist, 
	(SELECT COUNT(*) 
			FROM pizza_stores As s WHERE ST_Within(s.the_geom, r.the_geom)) As tot_stores
FROM pizza_regions As r
	INNER JOIN 
		(SELECT l.pl_id, MIN(ST_Distance(l.the_geom, s.the_geom)) AS min_dist, l.the_geom 
			FROM pizza_lovers As l 
				INNER JOIN pizza_stores AS s ON ST_DWithin(l.the_geom, s.the_geom,200*1600)
			--WHERE l.incbrack IN('M', 'H')
			GROUP BY l.pl_id, l.the_geom) As pl 
		ON ST_Within(pl.the_geom, r.the_geom)
GROUP BY r.region_name, r.the_geom
HAVING AVG(pl.min_dist) > 16000
ORDER BY totpop DESC, AVG(pl.min_dist) DESC;

5000