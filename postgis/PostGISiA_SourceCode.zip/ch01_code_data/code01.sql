-- Section 1.4.1 verifying PostGIS / PostgreSQL version
SELECT postgis_full_version();
SELECT version();

-- Section 1.4.2 - createing geometries with PostGIS
SELECT ST_Point(1, 2) AS MyFirstPoint;
SELECT ST_SetSRID(ST_Point(-77.036548, 38.895108),4326); -- long,lat
SELECT ST_AsEWKT('0101000020E6100000FD2E6CCD564253C0A93121E692724340');
SELECT ST_GeomFromText('LINESTRING(-14 21,0 0,35 26)') AS MyCheckMark;
SELECT ST_GeomFromText('POLYGON((0 1,1 -1,-1 -1,0 1))') As MyTriangle;
SELECT ST_GeomFromText('POLYGON((52 218, 139 82, 262 207, 245 261, 207 267, 153 207, 125 235, 90 270, 55 244, 51 219, 52 218))') As HeartPolygon;

-- listing 1.1 preparing tables
--Listing 1.1 Set up Fastfoods and Franchise lookup
CREATE SCHEMA ch01;                                                      --#1
CREATE TABLE ch01.lu_franchises(                                         --#2
                   franchise_code char(1) PRIMARY KEY,                  --#2
                   franchise_name varchar(100));                        --#2

INSERT INTO ch01.lu_franchises(franchise_code, franchise_name)          --#3
VALUES ('b', 'Burger King'),
        ('c', 'Carl''s Jr'),
        ('h', 'Hardee''s'),
        ('i', 'In-N-Out'),
        ('j', 'Jack in the Box'),
        ('k', 'Kentucky Fried Chicken'),
        ('m', 'McDonald''s'),
        ('p', 'Pizza Hut'),
        ('t', 'Taco Bell'),
        ('w', 'Wendy''s');

CREATE TABLE ch01.fastfoods                                             --#4
(
  franchise char(1) NOT NULL,
  lat double precision,
  lon double precision
);
--#1 Create logical container
--#2 Lookup table
--#3 Add franchise types
--#4 Table holds locations

-- Using SQL
COPY ch01.fastfoods FROM '/data/fastfoods.csv' DELIMITER ',';

-- Alternatively using psql /copy command from client statement included also in command line text file

-- Listing 1.2 Using the geometry data type to store data
SELECT AddGeometryColumn('ch01', 'fastfoods',                         --#1
  'geom', 2163, 'POINT',2);                    
UPDATE ch01.fastfoods 
   SET geom = ST_Transform(                                           --#2
      ST_GeomFromText('POINT(' || lon || ' ' || lat || ')',4326), 2163);

CREATE INDEX idx_fastfoods_geom                                       --#3
  ON ch01.fastfoods USING gist(geom);
vacuum analyze ch01.fastfoods;
--#1 Add column 
--#2 Use equal area planar
--#3 General maintenance


-- Listing 1.3 Using geography data type to store data
ALTER TABLE ch01.fastfoods ADD COLUMN geog geography(POINT,4326);   --#1
UPDATE ch01.fastfoods 
        SET geog =                                                  --#2
                ST_GeogFromText('SRID=4326;POINT(' || lon           
          || ' ' || lat || ')');
CREATE INDEX idx_fastfoods_geog ON ch01.fastfoods USING gist(geog); --#3
--#1 Add column 
--#2 Use geodetic
--#3 General maintenance

vacuum analyze ch01.fastfoods;


-- foreign key and primary key
ALTER TABLE ch01.fastfoods ADD COLUMN ff_id SERIAL PRIMARY KEY;

ALTER TABLE ch01.fastfoods 
	ADD CONSTRAINT fk_fastfoods_franchise 
	FOREIGN KEY (franchise) 
	REFERENCES ch01.lu_franchises (franchise_code)
   ON UPDATE CASCADE ON DELETE RESTRICT;

CREATE INDEX fki_fastfoods_franchise ON ch01.fastfoods(franchise);

-- Listing 1.4 Using geometry data type to store roads data
SELECT AddGeometryColumn('ch01', 'roads', 'geom', 2163,                --#1
 'MULTILINESTRING',2);
UPDATE ch01.roads                                                      --#2
	SET geom = 
		ST_Transform(geom_4269, 2163);
SELECT DropGeometryColumn('ch01', 'roads', 'geom_4269');               --#3

CREATE INDEX idx_roads_geom ON ch01.roads USING gist(geom);            --#4

-- 1 add column 
-- 2 use equal area planar meters
-- 3 drop old column
-- 4 general maintenance

vacuum analyze ch01.roads;

-- Listing 1.5 List franchise name, count of restaurants on a Principal Highway
SELECT ft.franchise_name,                                           --#1 
        COUNT(DISTINCT ff.ff_id) As tot
FROM ch01.fastfoods As ff 
        INNER JOIN ch01.lu_franchises As ft                            --#2
        ON ff.franchise = ft.franchise_code
        INNER JOIN ch01.roads As r                                    --#3
        ON ST_DWithin(ff.geom, r.geom, 1609*1)                         --#3
WHERE r.feature LIKE 'Principal Highway%' 
GROUP BY ft.franchise_name
ORDER BY tot DESC;
--#1 Distinct count
--#2 Nonspatial join
--#3 Spatial join

-- Listing 1.6 Return the principal highway that has the most restaurants and how many
SELECT r.name,                                                         --#1
  COUNT(DISTINCT ff.ff_id) As tot
FROM ch01.fastfoods As ff 
        INNER JOIN ch01.roads As r                              
        ON ST_DWithin(ff.geom, r.geom, 1609*0.5)                       --#2 
WHERE r.feature LIKE 'Principal Highway%' 
GROUP BY r.name
ORDER BY tot DESC LIMIT 1;                                             --#3
--#1 Distinct count
--#2 Within 1/2 mile
--#3 One with greatest total