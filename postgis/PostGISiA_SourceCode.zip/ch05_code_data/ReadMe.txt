Some examples in chapter 5 require data from chapter 1 in addition to the data in ch05_data.sql.

In order to complete the exercises in this chapter:
1) Using pgAdmin or psql -- run the ch05_data.sql
2) The code05.sql file contains code snippets discussed in Chapter 5 as well as complete listing in cases where only a partial listing was shown in the book.
