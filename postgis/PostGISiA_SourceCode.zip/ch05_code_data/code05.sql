-- secton 5.2.1

-- Segment slicing
SELECT ST_Intersects(g1.geom1,g1.geom2) As they_intersect, 
  GeometryType(
  ST_Intersection(g1.geom1, g1.geom2)) As intersect_geom_type
FROM (SELECT ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,
  -1.5 2.2,0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1, 
ST_GeomFromText('LINESTRING(-0.62 5.84,-0.8 0.59)') As geom2) AS g1;


-- Listing 5.1 Return our sales region diced up
SELECT x || ' ' || y As grid_x_y,                                   --[1]
    CAST(ST_MakeBox2d(
        ST_Point(-1.5 + x, 0 + y), 
        ST_Point(-1.5 + x + 2, 0 + y + 2)) As geometry) As geom2
FROM generate_series(0,3,2) As x 
    CROSS JOIN generate_series(0,6,2) As y;

SELECT ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,-1.5 2.2, 
0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1;                      --[2]

SELECT CAST(x AS text) || ' ' || CAST(y As text) As grid_xy ,       --[3]
 ST_AsText(ST_Intersection(g1.geom1, g2.geom2)) As intersect_geom
FROM (SELECT ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,
    -1.5 2.2,0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1) As g1
INNER JOIN (SELECT x, y, 
   CAST(ST_MakeBox2d(ST_Point(-1.5 + x, 0 + y), 
  ST_Point(-1.5 + x + 2, 0 + y + 2)) As geometry) As geom2
FROM generate_series(0,3,2) As x 
    CROSS JOIN generate_series(0,6,2) As y) As g2 
ON ST_Intersects(g1.geom1,g2.geom2) ;


--[1] squares to dice with
--[2] region
--[3] Dicing yields multiple records 

-- Section 5.3.1 Interior, exterior, and boundary of a geometry

-- Listing 5.2 Create sample geometries to exercise intersect relationships
CREATE TABLE example_set(ex_name varchar(150) PRIMARY KEY, 
    the_geom geometry);
INSERT INTO example_set(ex_name, the_geom)
VALUES 
('A polygon with hole', 
    ST_GeomFromText('POLYGON ((110 180, 110 335, 
    184 316, 260 335, 260 180, 209 212.51, 110 180), 
(160 280, 200 240, 220 280, 160 280))') ),
('A point',ST_GeomFromText('POINT(110 245)')) ,
('A linestring',
    ST_GeomFromText('LINESTRING(110 245,200 260, 227 309)')) ,
('A multipoint',
    ST_GeomFromText('MULTIPOINT(110 245,200 260)')) ;

-- Section 5.3.2 Contains and within
SELECT A.ex_name As a_name, B.ex_name As b_name, 
    ST_Contains(A.the_geom, B.the_geom) As a_co_b, 
    ST_Intersects(A.the_geom, B.the_geom) As a_in_b
FROM example_set As A CROSS JOIN example_set As B;


-- Section 5.3.3 Coverts and Covered By
-- Listing 5.3 How is ST_Covers different from ST_Contains?
SELECT A.ex_name As a_name, B.ex_name As b_name, 
    ST_Covers(A.the_geom, B.the_geom) As a_co_b,
    ST_Intersects(A.the_geom, B.the_geom) As a_in_b
FROM example_set As A CROSS JOIN example_set As B
WHERE NOT (ST_Covers(A.the_geom, B.the_geom) = 
  ST_Contains(A.the_geom, B.the_geom));


-- Section 5.3.4 Contains properly
-- Listing 5.4 How is ST_ContainsProperly different from ST_Contains
SELECT A.ex_name As a_name, B.ex_name As b_name, 
    ST_ContainsProperly(A.the_geom, B.the_geom) As a_co_b,
    ST_Intersects(A.the_geom, B.the_geom) As a_in_b
FROM example_set As A CROSS JOIN example_set As B
WHERE NOT (ST_ContainsProperly(A.the_geom, B.the_geom) = 
   ST_Contains(A.the_geom, B.the_geom));



-- Section 5.3.6 Touching geometries
-- Which pairs of these touch
SELECT A.ex_name As a_name, B.ex_name As b_name, 
    ST_Touches(A.the_geom, B.the_geom) As a_tou_b, 
    ST_Contains(A.the_geom, B.the_geom) As a_co_b
FROM example_set As A CROSS JOIN example_set As B
WHERE ST_Touches(A.the_geom, B.the_geom) ;

-- Section 5.3.7 Crossing geometries
-- which pairs cross
SELECT A.ex_name As a_name, B.ex_name As b_name, 
    ST_Touches(A.the_geom, B.the_geom) As a_tou_b, 
    ST_Contains(A.the_geom, B.the_geom) As a_co_b
FROM example_set As A CROSS JOIN example_set As B
WHERE ST_Touches(A.the_geom, B.the_geom) ;

-- Sectionn 5.4 The remainder: ST_DIfferent and ST_SymDifference
-- Listing 5.5 What is left of the polygon and line after clipping
SELECT ST_Intersects(g1.geom1,g1.geom2) As they_intersect,            --[1]
    GeometryType(ST_Difference(g1.geom1, g1.geom2)) 
    As intersect_geom_type
FROM (SELECT 
  ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,-1.5 2.2,
   0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1, 
ST_GeomFromText('LINESTRING(-0.62 5.84,-0.8 0.59)') As geom2) AS g1;

SELECT ST_Intersects(g1.geom1,g1.geom2) As they_intersect,         --[2]
    GeometryType(ST_Difference(g1.geom2, g1.geom1)) As intersect_geom_type
FROM (SELECT ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,-1.5 2.2,0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1, 
ST_GeomFromText('LINESTRING(-0.62 5.84,-0.8 0.59)') As geom2) AS g1;

SELECT ST_Intersects(g1.geom1,g1.geom2) As they_intersect,         --[3]
    GeometryType(ST_SymDifference(g1.geom1, g1.geom2)) As intersect_geom_type
FROM (SELECT 
 ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,-1.5 2.2,
 0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1, 
ST_GeomFromText('LINESTRING(-0.62 5.84,-0.8 0.59)') As geom2) AS g1;


--[1] Results in polygon
--[2] Results in multilinestring
--[3] Results in geometry collection


-- Listing 5.6 Bisecting a polygon using the knife trick
SELECT foo.path[1] As gid, 
 ST_AsText(
  ST_SnapToGrid(foo.geom, 0.0000001)) As wktpoly
FROM (SELECT g1.geom2 As the_knife_cut, 
  (ST_Dump(ST_Difference(g1.geom1, g1.geom2))).*
FROM 
  (SELECT 
ST_GeomFromText('POLYGON((2 4.5,3 2.6,3 1.8,2 0,
 -1.5 2.2,0.056 3.222,-1.5 4.2,2 6.5,2 4.5))') As geom1, 
ST_Buffer(
 ST_GeomFromText('LINESTRING(-0.62 5.84,-0.8 0.59)'),0.00000001) As geom2) AS g1
WHERE ST_Intersects(g1.geom1,g1.geom2)) As foo;



-- Section 5.5.1 Intersects with tolerance
SELECT 
    ST_DWithin(
        ST_GeomFromText('LINESTRING(1 2, 3 4)'), 
            ST_Point(3.00001,4.000001),
        0.0001
 ) ;
 
-- Section 5.5.2 Finding N closest objects
SELECT r.name, ST_Distance(r.geom, loc.geom)/1000 As dist_km
    FROM ch01.roads As r INNER JOIN
    (SELECT ST_Transform(
       ST_SetSRID(ST_Point(-118.42494, 37.31942), 4326),
         2163) As geom) As loc
  ON ST_DWithin(r.geom, loc.geom, 10000)
ORDER BY ST_Distance(r.geom, loc.geom) 
    LIMIT 5;

-- Listing 5.7 Find the closest road to each location; search 10 kilometers out
SELECT DISTINCT ON(loc.loc_name, loc.loc_type) loc.loc_name, 
    loc.loc_type, r.road_name, 
        ST_Distance(r.the_geom, loc.geom)/1000 As dist_km
FROM ch05.loc LEFT JOIN
        ch05.road As r
ON ST_DWithin(r.the_geom, loc.geom, 10000)
ORDER BY loc.loc_name, loc.loc_type, 
  ST_Distance(r.the_geom, loc.geom) ;




-- Listing 5.8 Find the closest 2 roads to each station search 1 kilometer out
SELECT pid, land_type, row_num, road_name,
      round(CAST(dist_km As numeric),2) As dist_km
FROM (SELECT 
ROW_NUMBER() OVER (PARTITION BY loc.pid                              -- [1]
        ORDER BY ST_Distance(r.the_geom, loc.the_geom)) As row_num,
      loc.pid,loc.land_type,r.road_name, 
     ST_Distance(r.the_geom, loc.the_geom)/1000 As dist_km
    FROM ch05.land As loc 
LEFT JOIN                                                            -- [2]
        ch05.road As r
ON ST_DWithin(r.the_geom, loc.the_geom, 1000) 
  WHERE loc.land_type = 'police station') As foo
  WHERE foo.row_num < 3                                              -- [3]
ORDER BY pid, row_num;

-- [1]  sequentially number by proximity
--[2] left join includes no matches
--[3] order by pid, proximity


-- Section  5.6 Bounding box and geometry comparators
--Listing 5.9 ST_Box2D and geometry
SELECT ex_name, ST_Box2D(the_geom) As bbox2d , the_geom
FROM (
VALUES 
 ('A line', ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')), 
('A multipoint',ST_GeomFromText('MULTIPOINT (4.4 4.75, 5 5)'))  ,
('A triangle', ST_GeomFromText('POLYGON ((2 5, 1.5 4.5, 2.5 4.5, 2 5))') )
)
AS foo(ex_name, the_geom);




-- Listing 5.10 ST_OrderingEquals equality vs. Spatial Equality
SELECT ex_name, ST_OrderingEquals(the_geom, the_geom) As g_oeq_g, 
	ST_OrderingEquals(the_geom, ST_Reverse(the_geom)) As g_oeq_rev,
	ST_OrderingEquals(the_geom, ST_Multi(the_geom)) AS g_oeq_m, 
	ST_Equals(the_geom, the_geom) As g_seq_g, 
	ST_EQuals(the_geom, ST_Multi(the_geom)) As g_seq_m
FROM (
VALUES 
('A 2d line', ST_GeomFromText('LINESTRING(3 5, 2 4, 2 5)') ),
('A point',ST_GeomFromText( 'POINT(2 5)'))  ,
('A triangle', ST_GeomFromText('POLYGON((3 5, 2.5 4.5, 2 5, 3 5))') ),
('poly with self-inter', ST_GeomFromText('POLYGON((2 0,0 0,1 1,1 -1, 2 0))')
)
)
AS foo(ex_name, the_geom);



-- Section 5.7.4 Boudning box equality
SELECT ST_GeomFromText('LINESTRING (3 5, 3.4 4.5, 4 5)') = ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))') As op_eq ;


SELECT ST_OrderingEquals(ST_GeomFromText('LINESTRING (3 5, 3.4 4.5, 4 5)') , ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))') ) As op_same;


-- Listing 5.11 DISTINCT is not always DISTINCT
SELECT ST_AsText(the_geom) 						-- [1]
	FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);

SELECT ST_AsText(the_geom)						-- [2]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);

SELECT DISTINCT the_geom					-- [3]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);

SELECT DISTINCT ST_AsText(the_geom)			-- [4]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);
--[1] 2 records
--[2] 1 record
--[3] 1 record
--[4] 2 records

-- Listing 5.12 A count DISTINCT is not always a DISTINCT count
SELECT COUNT(DISTINCT the_geom)					-- [1]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);
SELECT COUNT(DISTINCT the_geom)					-- [2]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 6, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom);

SELECT the_geom						-- [3]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom)
GROUP BY the_geom;

SELECT the_geom						-- [4]
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 6, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')

) As foo(the_geom)
GROUP BY the_geom;
--[1] Gives 1 as answer
--[2] Gives 2 as answer
--[3] Returns 1 geometry
--[4] Returns 2 geometries



-- Listing 5.13 Guaranteeing unique geometries
CREATE TABLE mygeom_unique(the_geom geometry);
INSERT INTO mygeom_unique(the_geom)
SELECT CAST(the_geom As text)
FROM (SELECT ST_GeomFromEWKT('LINESTRING (3 5, 3.4 4.5, 4 5)')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')
UNION ALL
SELECT ST_GeomFromText('POLYGON ((3 5, 3 4.5, 4 4.5, 3 5))')
) As foo(the_geom)
GROUP BY CAST(the_geom As text);


--Listing 5.14  ST_Equals testing � a  self-intersecting polygon is not equal to itself
SELECT ex_name, ST_Equals(the_geom, ST_Reverse(the_geom)) As g_eq_rev, 
	ST_Equals(the_geom, the_geom) As g_eq_g, 
	ST_AsText(ST_Reverse(the_geom)) As g_rev,
	ST_Relate(the_geom, ST_Reverse(the_geom)) As g_rel_rev, 
	ST_Equals(the_geom, ST_Multi(the_geom)) AS g_eq_m
FROM (
VALUES 
('A 2d line', ST_GeomFromText('LINESTRING(3 5, 2 4, 2 5)') ),
('A point',ST_GeomFromText( 'POINT(2 5)'))  ,
('A triangle', ST_GeomFromText('POLYGON((3 5, 2.5 4.5, 2 5, 3 5))') ),
('poly with self-inter', ST_GeomFromText('POLYGON((2 0,0 0,1 1,1 -1, 2 0))')
	)
)
AS foo(ex_name, the_geom);


--Listing 5.15 ST_Relate In action
WITH example_set(ex_name,the_geom) AS 				--[1 BEG]
(
SELECT ex_name, the_geom
	FROM (
VALUES 
('A 2d line', ST_GeomFromText('LINESTRING(3 5, 2.5 4.25, 1.6 5)') ),
('A point',ST_GeomFromText( 'POINT(1.6 5)'))  ,
('A triangle', ST_GeomFromText('POLYGON((3 5, 2.5 4.25, 1.9 4.9, 3 5))') )
	)
	AS foo(ex_name, the_geom)
)									--[1 END]
SELECT A.ex_name As a_name, B.ex_name As b_name, 			--[2 BEG]
	ST_Relate(A.the_geom, B.the_geom) As DE9IM,
	ST_Intersects(A.the_geom, B.the_geom) As inter, 
	ST_Relate(A.the_geom, B.the_geom, 'FF*FF****') As relate_disjoint,
 	NOT 
	ST_Relate(A.the_geom, B.the_geom, 'FF*FF****') As relate_intersect
FROM example_set As A 
	CROSS JOIN example_set As B;					--[2 END]
--[1] CTE example_set
--[2]  Relate sample set
