Datasources used in ths chapter are located in the data folder and included as both their native raster format as well as ready to load sql files.
To use, first create a ch13 schema.

Pele: pele.sql, pele_chunked.sql
downloaded from PostGIS website.

Kauai: kauai.sql 
The link when we downloaded it was:
http://duff.geology.washington.edu/data/raster/tenmeter/hawaii/index.html

But has been changed to
http://rocky.ess.washington.edu/data/raster/tenmeter/hawaii/index.html (and the format is now DEM instead of BIL)

Massachusetts USGS topos
ftp://data.massgis.state.ma.us/pub/images/usgs/

Vietnam: - vietelev.sql
http://data.geocomm.com/catalog/VM/datalist.html

The ch13_code.sql are the sql statements and scripts described in the chapter
ch13_commandline.txt are commandline examples described in the chapter.