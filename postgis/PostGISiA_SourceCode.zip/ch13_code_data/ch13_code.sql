-- determine srid of Kauai dataset
SELECT srid, proj4text
FROM spatial_ref_sys
WHERE proj4text ILIKE '%utm%' AND proj4text ILIKE '%zone=4 %'
 AND proj4text ILIKE '%datum=NAD83%'
 
-- Listing 13.1 Getting general summary info about rasters in a kauai table
SELECT count(*) As num_rasters, ST_Height(rast) As height, 
    ST_Width(rast) As width, ST_SRID(rast) As srid,
    ST_NumBands(rast) As num_bands,
    ST_BandPixelType(rast,1) As btype
FROM ch13.kauai
GROUP BY ST_Height(rast) ,
    ST_Width(rast), ST_SRID(rast),
    ST_NumBands(rast),
    ST_BandPixelType(rast,1);

-- seciton 13.4.1
-- metadata about raster columns in ch13 
--(note in Pre 2.0 WKT Raster scale_x, scale_y were pixelsize_x, pixelsize_y)
SELECT r_table_name As tname, r_column As col_name, 
   nodata_values As noval, srid, pixel_types, 
   scale_x As sx, scale_y As sy
FROM raster_columns
WHERE r_table_schema = 'ch13';


-- section 13.4.2
-- add a raster column with no constraints
ALTER TABLE ch13.pele ADD COLUMN rast_singband raster;
-- create table and add raster column with 4 bands
-- constrained to utm zone 4
CREATE TABLE 
ch13.pele_in_kauai(rid serial primary key, 
          twin varchar(30));
SELECT AddRasterColumn('ch13', 'pele_in_kauai', 'rast',26904,
    '{8BUI,8BUI,8BUI,8BUI}',
false, true, '{255,255,255,255}', 10,-10,299,439, null);

-- seciton 13.5 simple exercises
-- section 13.5.1
-- common raster accessors
SELECT ST_Height(rast) As nrows, ST_Width(rast) As ncols, 
    ST_NumBands(rast) As numbands, ST_SRID(rast)
FROM ch13.pele;

-- reading pixel values
SELECT ST_Value(rast,1,1,1) As b1val, 
      ST_Value(rast,2,1,1) As b2val, 
  ST_Value(rast,3,1,1) As b3val, 
 ST_Value(rast,4,1,1) As b4val, 
 ST_BandNoDataValue(rast,1) As b1nodata
FROM ch13.pele;


-- update band no data value
UPDATE ch13.pele 
     SET rast = 
          ST_SetBandNoDataValue(ST_SetBandNoDataValue(
               ST_SetBandNoDataValue(
                    ST_SetBandNoDataValue(
                         rast,1, 255)
                    ,2,255),
                    3,255),4,255) ;

-- envelope
SELECT ST_Envelope(rast) FROM ch13.pele;

-- polygonize a raster
SELECT ST_Polygon(rast) FROM ch13.pele;

--polygonize a raster with pixel size change
-- PostGIS 2.0
SELECT ST_Polygon(ST_SetScale(rast,1, -1)) FROM ch13.pele;
-- Older WKT Raster (0.1.6) variant
SELECT ST_Polygon(ST_SetPixelSize(rast,1, -1)) FROM ch13.pele;

-- create spatial index on raster
CREATE INDEX idx_gist_ch13_pele_rast
   ON ch13.pele USING gist (ST_ConvexHull(rast));

   
-- compare convex hull and envelope of skewed raster
SELECT ST_Envelope(rast_skew) As envelope, 
          ST_ConvexHull(rast_skew) As convexhull 
        FROM (SELECT ST_SetSkew(rast,0.5) As rast_skew 
               FROM ch13.pele) As foo;

--13.5.2 Georeferencing functions               
-- get pixel size PostGIS 2.0
SELECT ST_ScaleX(rast) As pixx, ST_ScaleY(rast) As pixy
FROM ch13.pele;

-- older uses ST_PixelSizeX, ST_PixelSizeY

-- set pixel size
UPDATE ch13.pele SET rast = ST_SetScale(rast, 1,-1);

-- equivalent polygonize
SELECT ST_Polygon(rast) FROM ch13.pele;
-- Which is equiavalent to writing:

SELECT ST_Polygon(rast,1) FROM ch13.pele;

-- fattening a raster polygon
-- PostGIS 2.0
SELECT ST_Polygon(ST_SetScale(rast,2,-1.5)) FROM ch13.pele;
-- older version wkt raster 0.1.6
SELECT ST_Polygon(ST_SetPixelSize(rast,2,-1.5)) FROM ch13.pele;


-- Listing 13.2 Creating 3 clones of Pele in Kauai 

INSERT INTO ch13.pele_in_kauai(twin, rast)                              -- #1
SELECT 'pele ' || i, 
          ST_SetSRID(
            ST_SetGeoReference(rast, '10 0 0 -10 ' 
             ||  433149.653768 + i  * ST_Width(rast) * 30 
          || ' ' ||  2440440.99542, 'GDAL'), 
                    26904)
     FROM ch13.pele 
     CROSS JOIN generate_series(1,3) As i;
UPDATE raster_columns                                                   -- #2
    SET extent = (SELECT 
                    ST_Union(ST_ConvexHull(rast)) 
                        FROM ch13.pele_in_Kauai)
                          WHERE 
             raster_columns.r_table_name = 'pele_in_kauai' 
          AND r_table_schema = 'ch13';
CREATE INDEX idx_gist_ch13_pele_in_kauai_rast                           -- #A
   ON ch13.pele_in_kauai USING gist (ST_ConvexHull(rast));

-- [1] create 3 peles across
-- [2] correct raster_columns extent
-- [a] index for better performance

-- 13.6 Combining Raster processing with vector processing
-- 13.6.1
-- GETTING A PIXEL VALUE AT A GEOMETRIC POINT ST_VALUE
SELECT p.twin, ST_Value(k.rast,1,p.geom) As elev_twin
FROM ch13.kauai  As k INNER JOIN 
(SELECT twin, ST_Centroid(ST_Envelope(rast)) 
  As geom FROM ch13.pele_in_kauai) As p 
ON ST_Intersects(k.rast, p.geom)
ORDER BY p.twin;

-- Setting pixel value at geometric point
UPDATE ch13.kauai SET ST_SetValue(k.rast,1,p.geom,400) As elev_twin
FROM (SELECT twin, ST_Centroid(ST_Envelope(rast)) 
  As geom FROM ch13.pele_in_kauai) As p 
WHERE ST_Intersects(k.rast, p.geom);

-- 13.6.2 Intersects and Intersections
-- Listing 13.3 Intersection of raster with geometry
SELECT CAST((gval).val As integer) AS val,                --[1]
     ST_AsBinary((gval).geom) As geom                    --[1]
FROM (
SELECT ST_Intersection(rast,1,buf.geom) As gval               --[2 Beg]
FROM ch13.kauai 
     INNER JOIN (
     SELECT ST_Buffer(
     ST_GeomFromText('POINT(444205 2438785)',26904),100) 
     As geom) As buf ON
    ST_Intersects(rast,buf.geom))      As foo                    --[2 End]
ORDER BY (gval).val
-- [1] pixelval and geometry
-- [2] intersected output

-- Pixel stats
SELECT SUM((gval).val* ST_Area((gval).geom))
     / ST_Area(ST_Collect((gval).geom)) As avg_elesqm
FROM (
SELECT ST_Intersection(rast,1,buf.geom) As gval
FROM ch13.kauai 
     INNER JOIN 
(SELECT ST_Buffer(
ST_GeomFromText('POINT(444205 2438785)',26904),100) 
As geom
) As buf ON
    ST_Intersects(rast,buf.geom))  As foo;

-- Listing 13.4 Adding a Z coordinate to 2D LineString
SELECT ST_AsEWKT(                              
    ST_SetSRID(
     ST_MakeLine(                         
          ST_MakePoint(                                          --[1]
                  ST_X((gd).geom), ST_Y((gd).geom),
               COALESCE(ST_Value(rast, (gd).geom),0 )            --[2]
          )
        ), 26904
     )
) As line_3dwkt
FROM (SELECT 
    ST_DumpPoints(                								--[3]
     ST_GeomFromText('LINESTRING(444210 2438785,                 
          434125 2448785,  466666 2449780, 
          47000 2459000)',
          26904 )
        ) As gd
   ) 
    As trail 
     LEFT JOIN ch13.kauai 
     ON ST_Intersects(rast, (gd).geom);                          --[4]
--[1] aggregate points into a line
--[2] make pixel value Z
--[3] get points from linestring
--[4] rasters that intersect


-- 13.6.3 Adding bands

-- correct orientation --
--PostGIS 2.0
UPDATE ch13.pele_chunked 
     SET rast = ST_SetUpperLeft(ST_SetScale(rast, 1, -1),
     ST_UpperLeftX(rast), -ST_UpperLeftY(rast));
     
-- old wkt raster 0.1.6
UPDATE ch13.pele_chunked 
     SET rast = ST_SetUpperLeft(ST_SetPixelSize(rast, 1, -1),           
     ST_UpperLeftX(rast), -ST_UpperLeftY(rast));
     
SELECT rid, ST_AsBinary(ST_Envelope(rast)) FROM ch13.pele_chunked;

SELECT ST_AsBinary((ST_SetBandNoDataValue(rast,1, 255)))
from ch13.pele_chunked
where rid = 8;

CREATE TABLE ch13.pele_ball(rid integer PRIMARY KEY);
-- Add a new raster with just one band georeferenced to web mercator
SELECT AddRasterColumn('ch13', 'pele_ball', 'rast',3785,
    '{16BUI}',false, true, '{0}', 142128,-138516,50,50, null);
    
SELECT AddRasterColumn('ch13', 'pele_ball', 'rast_pre',3785,
    '{8BUI,8BUI, 8BUI, 8BUI}',false, true, '{0}', 142128,-138516,50,50, null);

DELETE FROM ch13.pele_ball;

--ST_MakeEmptyRaster(integer width, integer height, float8 ipx, float8 ipy, float8 scalex, float8 scaley, float8 skewx, float8 skewy, integer srid);
-- create a 1 band raster for each time and initialize to 255 and nodatavalue 0

-- determine average - 199 for first band
SELECT SUM(ST_Area((g).geom)*(g).val)/SUM(ST_Area((g).geom))
FROM (SELECT ST_DumpAsPolygons(rast) As g1, 
		FROM ch13.pele_chunked
		WHERE rid between 1 and 8) As b1 ;
		
INSERT INTO ch13.pele_ball(rid,rast)
	SELECT rid, ST_AddBand(ST_MakeEmptyRaster(50,50,
		(-19951913 + 5*1483550) + ST_UpperLeftX(rast)*rid*(142128/50),
		(-1643353 + 5*1385160) + ST_UpperLeftY(rast)*rid*(-138516/50),142128,-138516,0,0, 3785), '16BUI',255,0)
	FROM ch13.pele_chunked
		WHERE rid BETWEEN 1 and 8;

-- update pixels to no-data value that 		
SELECT SUM(ST_Area((g).geom*(g).val))/SUM((g).val)
FROM (SELECT ST_DumpAsPolygons(rast) As g
		FROM ch13.pele_chunked
		WHERE rid between 1 and 8) As foo;
		
SELECT (g).val As g1val, ST_Union((g).geom) As g1
FROM (SELECT ST_DumpAsPolygons(rast,1) As g
		FROM ch13.pele_chunked
		WHERE rid between 1 and 1) As foo
GROUP BY (g).val
LIMIT 1;
		

CREATE OR REPLACE FUNCTION ch13.reclass_pele(rast raster, rast2 raster)
    RETURNS raster AS 
    $$
    DECLARE
        newrast raster := rast2;
        cx int;
        cy int;
        newwidth int := ST_Width(rast);
        newheight int := ST_Height(rast);
    BEGIN
		FOR i IN 1 .. newwidth  LOOP
			FOR j IN 1 .. newheight LOOP
					IF ST_Value(rast,1,i,j) BETWEEN 1 and 45 
						AND ST_Value(rast,2,i,j) BETWEEN 1 and 50 THEN --[1]
						newrast := ST_SetValue(newrast,1,i,j,1);
					ELSIF ST_Value(rast,1,i,j) BETWEEN 50 AND 70 AND 
						ST_Value(rast,2,i,j) BETWEEN 51 and 70 
                        AND NOT EXISTS(SELECT 1 
							FROM generate_series(-2,2) As x 
							   CROSS JOIN generate_series(-2,2) AS y 
								WHERE ST_Value(rast,1,
									greatest(1,least(newwidth,i - x)
										),
									greatest(1,
										least(newheight,j - y)
										)
									) BETWEEN 1 and 45 
							AND ST_Value(rast,2,greatest(1,
								least(newwidth,i - x)
									),
									greatest(1,
										least(newheight,j - y)
										)
								) 
								BETWEEN 1 and 50) 
								THEN --[2]
                            newrast := ST_SetValue(newrast,1,i,j,2);
					END IF;
			END LOOP;
		END LOOP;
		RETURN newrast;
    END;
    $$
LANGUAGE 'plpgsql'; 
-- [1] isolate the globe (ball)
-- [2] isolate other black lines not in ball

ALTER TABLE ch13.pele_chunked ADD COLUMN rast_simp raster;
UPDATE ch13.pele_chunked SET rast_simp = ST_AddBand(ST_MakeEmptyRaster(rast),'2BUI',0,0) ; 
UPDATE ch13.pele_chunked SET rast_simp = ch13.reclass_pele(rast,rast_simp) ; 


SELECT ST_AsBinary(ST_Union(ST_Polygon(rast_simp)))
FROM ch13.pele_chunked;

SELECT ST_AsBinary(ST_Union(ST_Polygon(rast_simp)))
FROM ch13.pele_chunked;


SELECT (foo.g).val,  ST_AsBinary(ST_Union((foo.g).geom)) As geomwkb
FROM (SELECT ST_DumpAsPolygons(rast_simp) As g 
	FROM ch13.pele_chunked) As foo
	GROUP BY (foo.g).val;
