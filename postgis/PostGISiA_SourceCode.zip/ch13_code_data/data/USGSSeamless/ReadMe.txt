To create this raster we

1) Went to http://seamless.usgs.gov/website/seamless/viewer.htm?startbottom=5.0&starttop=85.0&startleft=-170&startright=-60.0&limitbottom=-85.0&limittop=85.0&limitleft=-179.5&limitright=179.5
2) Zoomed in a bit
3) Chose the Elevation -- NED Shaded Relief 1 arc per second
4) Used their print to save to PDF
5) Clipped the image
6) We know the spatial ref is WGS 84 long lat since its in degrees.  So we overlaid with our US boundaries that are in WGS 84
and from that determined

The top upper left corner is   -124.85, 49.42 (long lat)
and our pixel size divided is about 0.05, -0.05 degrees per pixel. 

We also assume know skew

From this we built our world file tfw

7)                    0.05 
                   0.00000000000000 
                   0.00000000000000 
                  -0.05
               -124.85
              49.42
              
8) Then loaded this up with
C:\python25\python raster2pgsql.py -s 4326 -r USGSSeamless\US.tif -t ch13.usdem -l 1 -k 130x79 -o USGSSeamless\usdem.sql 
"C:\Program Files\PostgresQL\8.4\bin\psql" -h localhost -d wktraster_postgis15 -U postgres -f USGSSeamless\usdem.sql
