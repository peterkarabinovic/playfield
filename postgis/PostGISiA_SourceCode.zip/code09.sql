-- Listing 9.1 Planner statistics query for our US States
-- 1 we do a vacuum analyze to insure we have planner statistics 
vacuum analyze us.states;

-- 2 interrogate the pg_stats view for the table we�ve just analyzed.
SELECT attname As colname, n_distinct,
		   array_to_string(most_common_vals, E'\n') AS common_vals,
		   array_to_string(most_common_freqs, E'\n') As dist_freq
  FROM pg_stats
  WHERE schemaname = 'us' and tablename = 'states';

  
-- Listing 9.2 The basic explain
EXPLAIN SELECT c.city, b.bridge_nam
FROM sf.cities AS c INNER JOIN 
	sf.bridges As b ON ST_Intersects(c.the_geom, b.the_geom);

-- result basic explain
/**  QUERY PLAN

-----------------------------------------------------------------------
 Nested Loop  (cost=14.40..1185.55 rows=1 width=128)
   Join Filter: ((c.the_geom && b.the_geom) AND
		 _st_intersects(c.the_geom, b.the_geom))
   ->  Seq Scan on cities c  (cost=0.00..21.15 rows=115 width=9809)
   ->  Materialize  (cost=14.40..18.40 rows=400 width=150)
         ->  Seq Scan on bridges b  (cost=0.00..14.00 rows=400 width=150)
**/

-- Listing 9.3 The explain with analysis

EXPLAIN ANALYZE SELECT c.city, b.bridge_nam
FROM sf.cities AS c INNER JOIN 
	sf.bridges As b ON ST_Intersects(c.the_geom, b.the_geom);
-- result explain analyze
/**   QUERY PLAN

----------------------------------------------------------
 Nested Loop  (cost=14.40..1185.55 rows=1 width=128) 
		(actual time=135.028..159.759 rows=8 loops=1)
   Join Filter: ((c.the_geom && b.the_geom) 
	AND _st_intersects(c.the_geom, b.the_geom))
   ->  Seq Scan on cities c  (cost=0.00..21.15 rows=115 width=9809) 
	(actual time=31.796..32.277 rows=115 loops=1)
   ->  Materialize  (cost=14.40..18.40 rows=400 width=150) 
			(actual time=0.148..0.150 rows=4 loops=115)
         ->  Seq Scan on bridges b  (cost=0.00..14.00 rows=400 width=150) 		(actual time=16.930..16.937 rows=4 loops=1)
 Total runtime: 163.551 ms
**/

-- Listing 9.4 Explain with verbose analysis
EXPLAIN ANALYZE VERBOSE SELECT c.city, b.bridge_nam
FROM sf.cities AS c INNER JOIN 
	sf.bridges As b ON ST_Intersects(c.the_geom, b.the_geom);
-- result of verboseness
/** QUERY PLAN

-------------------------------------------
 Nested Loop  (cost=14.40..1185.55 rows=1 width=128) 
		(actual time=4.114..36.481 rows=8 loops=1)
   Output: c.city, b.bridge_nam
   Join Filter: ((c.the_geom && b.the_geom) 
		AND _st_intersects(c.the_geom, b.the_geom))
   ->  Seq Scan on cities c  (cost=0.00..21.15 rows=115 width=9809) 
		(actual time=0.007..0.099 rows=115 loops=1)
         Output: c.gid, c.city, c.area__, c.length__, c.the_geom
   ->  Materialize  (cost=14.40..18.40 rows=400 width=150) 
		(actual time=0.001..0.003 rows=4 loops=115)
         Output: b.bridge_nam, b.the_geom
         ->  Seq Scan on bridges b  (cost=0.00..14.00 rows=400 width=150) 		(actual time=0.006..0.010 rows=4 loops=1)
               Output: b.bridge_nam, b.the_geom
 Total runtime: 40.118 ms
 **/
 
-- Listing 9.5 Index, Vacuum, Explain
-- 1 index
CREATE INDEX idx_sf_bridges_the_geom
   ON sf.bridges USING gist (the_geom)
  WITH (FILLFACTOR=90);

CREATE INDEX idx_sf_cities_the_geom
   ON sf.cities USING gist (the_geom)
  WITH (FILLFACTOR=90);

-- 2 update stats
vacuum analyze sf.bridges;
vacuum analyze sf.cities;

EXPLAIN ANALYZE VERBOSE SELECT c.city, b.bridge_nam
FROM sf.cities AS c INNER JOIN 
	sf.bridges As b ON ST_Intersects(c.the_geom, b.the_geom);

-- 3 result of explain

/**        QUERY PLAN

----------------------------------------------------------
 Nested Loop  (cost=0.00..22.17 rows=4 width=35) 
	(actual time=0.609..30.487 rows=8 loops=1)
   Output: c.city, b.bridge_nam
   Join Filter: _st_intersects(c.the_geom, b.the_geom)
   ->  Seq Scan on bridges b  (cost=0.00..1.04 rows=4 width=401) 
	(actual time=0.010..0.019 rows=4 loops=1)
         Output: b.gid, b.objectid, b.id, b.bridge_nam, b.the_geom
   ->  Index Scan using idx_sf_cities_the_geom on cities c  
	(cost=0.00..5.27 rows=1 width=9809) 
	(actual time=0.048..0.060 rows=3 loops=4)
         Output: c.gid, c.city, c.area__, c.length__, c.the_geom
         Index Cond: (c.the_geom && b.the_geom)
 Total runtime: 31.613 ms
**/

-- Listing 9.6 Compare plans/speeds between regular geometry and geography index
-- 1 geography index
CREATE INDEX idx_sometable_the_geom_geography
  ON sometable
  USING gist
  (geography(ST_Transform(the_geom,4326)));

vacuum analyze sometable;
-- 2  create view for future use
CREATE VIEW vwsometable AS 
	SELECT *, geography(ST_Transform(the_geom,4326)) As the_geog	
	FROM sometable As t;
-- 3 use view
SELECT s1.field1 As s1_field1, s2.field1 As s2_field1
FROM vwsometable As s1 INNER JOIN
	vwsometable  AS s2 
	ON(s1.gid <> s2.gid AND ST_DWithin(s1.the_geog, s2.the_geog, 5000));

	
-- Listing 9.7 a soundex index at work
-- to use soundex, need to load -- share\contrib\fuzzystrmatch.sql 
CREATE INDEX idx_sf_stclients_streets_soundex
  ON sf.stclines_streets
  USING btree
  (soundex(street));

vacuum analyze sf.stclines_streets;

SELECT DISTINCT street from sf.stclines_streets 
WHERE soundex(street) = soundex('Devonshyer');


-- Listing 9.8 The subselect in the select
EXPLAIN ANALYZE SELECT c.city, (SELECT COUNT(*) AS cnt 
		FROM sf.stclines_streets As s 
		WHERE  ST_Intersects(c.the_geom, s.the_geom) ) As cnt
FROM sf.distinct_cities As c
ORDER BY c.city;
-- result
/**
  QUERY PLAN
-----------------
 Sort  (cost=825.49..825.73 rows=98 width=11484) 
	(actual time=3663.059..3663.103 rows=98 loops=1)
   Sort Key: c.city
   Sort Method:  quicksort  Memory: 22kB
   ->  Seq Scan on distinct_cities c 
 (cost=0.00..822.25 rows=98 width=11484) 
	(actual time=1.464..3662.481 rows=98 loops=1)
         SubPlan 1
           ->  Aggregate  (cost=8.28..8.29 rows=1 width=0) 
           (actual time=37.367..37.368 rows=1 loops=98)
                 ->  Index Scan using idx_sf_stclines_streets_the_geom 
                 on stclines_streets s  (cost=0.00..8.27 rows=1 width=0) 
                 (actual time=12.567..37.226 rows=158 loops=98)
                       Index Cond: ($0 && the_geom)
                       Filter: _st_intersects($0, the_geom)
 Total runtime: 3664.534 ms
**/


-- Listing 9.9 Count of streets in each city using no subselect at all
EXPLAIN ANALYZE SELECT c.city, COUNT(s.gid) AS cnt
FROM sf.distinct_cities As c 
   LEFT JOIN sf.stclines_streets As s
       ON ( ST_Intersects(c.the_geom, s.the_geom) )
GROUP BY c.city
ORDER BY c.city;
-- results
/** QUERY PLAN
----------------------------
 GroupAggregate  (cost=649.24..651.20 rows=98 width=14) 
 (actual time=3720.125..3737.232 rows=98 loops=1)
   ->  Sort  (cost=649.24..649.49 rows=98 width=14) 
   (actual time=3720.102..3726.944 rows=15610 loops=1)
         Sort Key: c.city
         Sort Method:  quicksort  Memory: 1350kB
         ->  Nested Loop Left Join  (cost=0.00..646.00 rows=98 width=14) 
         (actual time=1.228..3689.535 rows=15610 loops=1)
               Join Filter: _st_intersects(c.the_geom, s.the_geom)
               ->  Seq Scan on distinct_cities c  
(cost=0.00..9.98 rows=98 width=11484) 
(actual time=0.008..0.079 rows=98 loops=1)
               ->  Index Scan using idx_sf_stclines_streets_the_geom on stclines_streets s  
               (cost=0.00..6.48 rows=1 width=332) 
		(actual time=0.018..0.682 rows=318 loops=98)
                     Index Cond: (c.the_geom && s.the_geom)
 Total runtime: 3738.086 ms
**/


-- Listing 9.10 Subselects gone too far
EXPLAIN ANALYZE SELECT c.city, (SELECT COUNT(*) AS cnt 
		FROM sf.stclines_streets As s 
		WHERE  ST_Intersects(c.the_geom, s.the_geom) ) As cnt,
            (SELECT COUNT(*) AS cnt 
		FROM sf.stclines_streets As s 
		WHERE  ST_Intersects(c.the_geom, s.the_geom) AND ST_Length(s.the_geom) > 1000) As cnt_gt_1000
		
FROM sf.distinct_cities As c
	WHERE EXISTS(SELECT s.gid 
		FROM sf.stclines_streets As s 
		WHERE  ST_Intersects(c.the_geom, s.the_geom) )
ORDER BY c.city;


-- Listing 9.11 Explain plan of subselect gone too far query
/**   QUERY PLAN

-----------------------
 Sort  (cost=662.59..662.60 rows=1 width=11484) 
 (actual time=8553.707..8553.709 rows=4 loops=1)
   Sort Key: c.city
   Sort Method:  quicksort  Memory: 17kB
   ->  Nested Loop Semi Join  (cost=0.00..662.58 rows=1 width=11484) 
   (actual time=16.260..8553.659 rows=4 loops=1)
         Join Filter: _st_intersects(c.the_geom, s.the_geom)
         ->  Seq Scan on distinct_cities c  
            (cost=0.00..9.98 rows=98 width=11484) 
            (actual time=0.005..0.078 rows=98 loops=1)
         ->  Index Scan using idx_sf_stclines_streets_the_geom on stclines_streets s  
            (cost=0.00..6.48 rows=1 width=328) 
            (actual time=0.018..0.166 rows=68 loops=98)
               Index Cond: (c.the_geom && s.the_geom)
         SubPlan 1
           ->  Aggregate  (cost=8.28..8.29 rows=1 width=0) 
           (actual time=924.351..924.352 rows=1 loops=4)
                 ->  Index Scan using idx_sf_stclines_streets_the_geom on stclin
es_streets s  (cost=0.00..8.27 rows=1 width=0) 
        (actual time=312.990..921.197 rows=3879 loops=4)
                       Index Cond: ($0 && the_geom)
                       Filter: _st_intersects($0, the_geom)
         SubPlan 2
           ->  Aggregate  (cost=8.28..8.29 rows=1 width=0) 
           (actual time=909.088..909.089 rows=1 loops=4)
                 ->  Index Scan using idx_sf_stclines_streets_the_geom on stclines_streets s  
                 (cost=0.00..8.28 rows=1 width=0) 
                 (actual time=305.862..908.947 rows=124 loops=4)
                       Index Cond: ($0 && the_geom)
                       Filter: (_st_intersects($0, the_geom) AND (st_length(the_geom) > 1000::double precision))
 Total runtime: 8555.406 ms
**/

-- Listing 9.12 Counts of streets and those with length limit using no subselects
EXPLAIN ANALYZE SELECT c.city, COUNT(s.gid) AS cnt, 
    COUNT(CASE WHEN ST_Length(s.the_geom) > 1000 THEN 1 ELSE NULL END)  As cnt_gt_1000
FROM sf.distinct_cities As c 
   INNER JOIN sf.stclines_streets As s
       ON ( ST_Intersects(c.the_geom, s.the_geom) )
GROUP BY c.city
ORDER BY c.city;

-- Listing 9.13 Query plan of count of streets and min length with no subselects
/** QUERY PLAN
------------------------------------
 Sort  (cost=728.48..728.73 rows=98 width=342) 
 (actual time=3751.973..3751.975 rows=4 loops=1)
   Sort Key: c.city
   Sort Method:  quicksort  Memory: 17kB
   ->  HashAggregate  (cost=723.28..725.24 rows=98 width=342) 
   (actual time=3751.932..3751.936 rows=4 loops=1)
         ->  Nested Loop  (cost=0.00..646.00 rows=10304 width=342) 
         (actual time=1.356..3700.814 rows=15516 loops=1)
               Join Filter: _st_intersects(c.the_geom, s.the_geom)
               ->  Seq Scan on distinct_cities c  
               (cost=0.00..9.98 rows=98 width=11484) 
               (actual time=0.005..0.074 rows=98 loops=1)
               ->  Index Scan using idx_sf_stclines_streets_the_geom on stclines_streets s  
               (cost=0.00..6.48 rows=1 width=332) 
               (actual time=0.018..0.667 rows=318 loops=98)
                     Index Cond: (c.the_geom && s.the_geom)
 Total runtime: 3752.642 ms
**/

-- Listing 9.14 Using offset to encourage materialization
SELECT a_gid, b_gid,
	dist/1000 As dist_km, dist As dist_m
FROM (SELECT a.gid As a_gid, b.gid As b_gid, 
		ST_Distance(a.the_geom, b.the_geom) As dist
	FROM poly As a INNER JOIN poly As b
 ON (ST_Dwithin(a.the_geom, b.the_geom, 1000)  AND a.gid != b.gid)
	
 OFFSET 0
 ) As foo;

 
-- Listing 9.15 Rank number results -- using the self join approach (pre-PostgreSQL 8.4)
SELECT count(p3.gid) As rank, main.p2_gid As gid, main.city_2, main.dist
FROM 
-- 1 using a subselect to define a virtual worktable we will use extensively which determines what cities are within 500 feet of ALBANY
(SELECT p1.city As city_1, p2.city As city_2, p1.the_geom As p1_the_geom, p2.the_geom As p2_the_geom, p2.gid As p2_gid,
    ST_Distance(p1.the_geom, p2.the_geom) As dist, p1.gid As p1_gid
FROM (SELECT city, gid, the_geom FROM sf.cities WHERE city = 'ALBANY') As p1
  INNER JOIN sf.cities AS p2 ON (p1.gid <> p2.gid AND ST_DWithin(p1.the_geom, p2.the_geom, 500) )
-- 2 We are using the OFFSET hack described to encourage caching.  Without the OFFSET our query takes 2 seconds and with the OFFSET the timing is reduced to 719ms (fairly significant improvement)
  OFFSET 0
) As main  
-- 3 doing a self-join to collect and count all the cities that are closer to ALBANY than our reference p2 in main.  
 -- Note the or main.p2_gid = p3.gid -- this is so our RANK will count at least our reference geom even if there is no closer object
    INNER JOIN sf.cities As p3 ON ( ST_DWithin(main.p1_the_geom, p3.the_geom, 500) )
 WHERE  (main.p2_gid = p3.gid OR ST_Distance(main.p1_the_geom, p3.the_geom) < main.dist ) AND main.p1_gid <> p3.gid
 GROUP BY main.p2_gid, main.city_2, main.dist
 ORDER BY rank, main.city_2;

 
-- Listing 9.16 Using window aggs to number results - PostgreSQL 8.4+ (short and faster)
SELECT RANK() OVER w_dist As rank, 
	p2.city As city_2, ST_Distance(p1.the_geom, p2.the_geom) As dist
FROM sf.cities As p1 INNER JOIN sf.cities As p2
 ON (p1.gid <> p2.gid AND ST_DWithin(p1.the_geom, p2.the_geom, 500))
 WHERE p1.city = 'ALBANY' 
-- 1
WINDOW w_dist AS (PARTITION BY p1.gid 
	ORDER BY ST_Distance(p1.the_geom, p2.the_geom)) 
 ORDER BY RANK() OVER w_dist, p2.city;

 
-- Listing 9.17 Simplified state vs. non-simplified
-- 1 takes 21964 ms  - 222 rows
SELECT a.state As st_a, b.state As st_b
FROM us.states AS a INNER JOIN us.states AS b 
	ON (a.state != b.state AND ST_DWithin(a.the_geom, b.the_geom,1000) ) ;

-- 2 prepare simplified
SELECT state, ST_SimplifyPreserveTopology(the_geom,1500) As the_geom
 INTO us.states_simp1500
 FROM us.states;

CREATE INDEX idx_us_states_simp1500_the_geom
  ON us.states_simp1500 USING gist(the_geom);

vacuum analyze us.states_simp1500;

-- 3 same query on simplified  - 9376 ms � 222 rows
SELECT a.state As st_a, b.state As st_b
FROM us.states_simp1500 AS a INNER JOIN us.states_simp1500 AS b 
	ON (a.state != b.state AND ST_DWithin(a.the_geom, b.the_geom,1000) ) ;

	
-- Listing 9.18 Simplify on the fly and still use an index
-- 1 create a new function that behaves like the built in PostGIS ST_DWithin function except that it applies a simplification tolerance before doing the distance within check
CREATE FUNCTION upgis_DWithin_Simplify(geom1 geometry, geom2 geometry, dist double precision,
simplify_tolerance double precision)
RETURNS boolean
 AS
  $$ SELECT ST_Expand($1, $3) && $2 AND ST_Expand($2, $3) && $1
AND _ST_DWithin(ST_SimplifyPreserveTopology($1,$4),
ST_SimplifyPreserveTopology($2,$4), $3)
$$
language 'sql' IMMUTABLE;

-- 2  takes 14727 ms � 222 rows
SELECT a.state As st_a, b.state As st_b
FROM us.states AS a INNER JOIN us.states AS b 
	ON (a.state != b.state AND upgis_DWithin_Simplify(a.the_geom, b.the_geom,1000,1500) ) ;

-- 3  at 4000 tol -  8408 ms � 222 rows
SELECT a.state As st_a, b.state As st_b
FROM us.states AS a INNER JOIN us.states AS b 
	ON (a.state != b.state AND 
upgis_DWithin_Simplify(a.the_geom, b.the_geom,1000,4000) ) ;


-- Listing 9.19 Remove all holes using subselect
SELECT s.gid, s.city, ST_Collect(ST_MakePolygon(s.the_geom)) As the_geom
FROM (SELECT gid, city, ST_ExteriorRing((ST_Dump(the_geom)).geom) As the_geom
 FROM sf.cities )  As s
 GROUP BY gid, city;

 

-- Listing 9.20 Filter Rings function and its application
-- This is copied from  http://www.spatialdbadvisor.com/postgis_tips_tricks/92/filtering-rings-in-polygon-postgis/ 
CREATE OR REPLACE FUNCTION filter_rings(geometry, double precision)
  RETURNS geometry AS
$BODY$
SELECT ST_BuildArea(ST_Collect(b.final_geom)) as filtered_geom
  FROM (SELECT ST_MakePolygon((/* Get outer ring of polygon */
		SELECT ST_ExteriorRing(a.the_geom) as outer_ring /* ie the outer ring */
		),  ARRAY(/* Get all inner rings > a particular area */
		 SELECT ST_ExteriorRing(b.geom) as inner_ring
		   FROM (SELECT (ST_DumpRings(a.the_geom)).*) b
		  WHERE b.path[1] > 0 /* ie not the outer ring */
		    AND ST_Area(b.geom) > $2
		) ) as final_geom
         FROM (SELECT ST_GeometryN(ST_Multi($1),
  /*ST_Multi converts any Single Polygons to MultiPolygons */
                                   generate_series(1,ST_NumGeometries(ST_Multi($1)))
                                   ) as the_geom
               ) a
       ) b
$BODY$
  LANGUAGE 'sql' IMMUTABLE;
  
  
-- Listing 9.21 Filter rings at work - remove all holes less than 51000 sq ft.
-- 1 returns a new dataset with all the holes less than 51000 sq ft removed from the original geometries
SELECT s.city, filter_rings(the_geom, 51000) As newgeomnohole_lt5000
FROM sf.cities;

-- 2 The second query tells you which geometries would be possibly affected by the operation
SELECT city, filter_rings(the_geom, 51000)) As newgeom
FROM (SELECT city, the_geom, (SELECT SUM(ST_NumInteriorRings(geom)) FROM ST_Dump(the_geom) ) As NumHoles
FROM sf.cities) As c
WHERE c.NumHoles > 0;

-- Listing 9.22 Collecting points into multipoint bunches 

SELECT max(obsid) As obsid, ST_Multi(ST_Collect(the_geom)) As the_geom, 
	obs_name, max(obs_date) as max_date, 
	min(obs_date) As min_date
-- 1 take the last id as our new id, the collected points that snap to the same grid and share the same name, use the name, 
 -- and store the min and max observation dates of our collected points
INTO work.observations_bunched
FROM us.observations
--2 transform to national atlas meters so that our snap to grid measurements will be in meters
GROUP BY ST_SnapToGrid(ST_Transform(the_geom,2163),50000,50000), obs_name;


