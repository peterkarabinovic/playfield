-- Listing 3.1 Code to partition roads into various states
CREATE TABLE roads(gid serial PRIMARY KEY, road_name character varying(100));

SELECT AddGeometryColumn('public', 'roads', 'geom', 4269, 'LINESTRING',2);

CREATE TABLE roads_NE(CONSTRAINT pk PRIMARY KEY (gid))            --[1]
INHERITS (roads);                                                 --[1]

ALTER TABLE roads_NE                                              --[2]
ADD CONSTRAINT chk CHECK (state                                   --[2]
   IN ('MA', 'ME', 'NH', 'VT', 'CT', 'RI'));                      --[2]

CREATE TABLE roads_SW(CONSTRAINT pk PRIMARY KEY (gid))
INHERITS (roads);

ALTER TABLE roads_SW
ADD CONSTRAINT chk CHECK (state IN ('AZ', 'NM', 'NV'));

SELECT gid, road_name, geom FROM roads WHERE state = 'MA';       --[3]



CREATE TABLE ch03.paris_hetero(gid serial NOT NULL, osm_id integer, 
  geom geometry, ar_num integer, tags hstore,
  CONSTRAINT paris_hetero_pk PRIMARY KEY (gid),
  CONSTRAINT enforce_dims_geom CHECK (st_ndims(geom) = 2),
  CONSTRAINT enforce_srid_geom CHECK (st_srid(geom) = 32631)
);


-- Listing 3.2 Region tagging and clipping data to a specific arrondissement
INSERT INTO ch03.paris_hetero(osm_id, geom, ar_num, tags)          --[1 BEG]
SELECT o.osm_id, ST_Intersection(o.geom, a.geom) As geom, 
      a.ar_num, o.tags
FROM 
(SELECT osm_id, ST_Transform(way, 32631) As geom, 
tags FROM planet_osm_line) AS o
  INNER JOIN ch03.arrondissements AS A 
    ON (ST_Intersects(o.geom, a.geom));                           --[1 END]

-- repeat for planet_osm_polygon, planet_osm_point -- not shown in book
INSERT INTO ch03.paris_hetero(osm_id, geom, ar_num, tags)         
SELECT o.osm_id, ST_Intersection(o.geom, a.geom) As geom, 
      a.ar_num, o.tags
FROM 
(SELECT osm_id, ST_Transform(way, 32631) As geom, tags FROM planet_osm_polygon) AS o 
  INNER JOIN ch03.arrondissements AS A ON (ST_Intersects(o.geom, a.geom));                                  

INSERT INTO ch03.paris_hetero(osm_id, geom, ar_num, tags)         
SELECT o.osm_id, o.geom, 
      a.ar_num, o.tags
FROM 
(SELECT osm_id, ST_Transform(way, 32631) As geom, tags FROM planet_osm_point) AS o 
  INNER JOIN ch03.arrondissements AS A ON (ST_Intersects(o.geom, a.geom));  

-- end repeat
CREATE INDEX idx_paris_hetero_geom                                --[2 BEG]
    ON ch03.paris_hetero USING gist(geom);
CREATE INDEX idx_paris_hetero_tags 
    ON ch03.paris_hetero USING gist(tags);
VACUUM ANALYZE ch03.paris_hetero;                                 --[2 END]

-- 1 Insert data and clip to specific arrondissement
-- 2 Add indexes and update statistics


SELECT ar_num, COUNT(DISTINCT osm_id) As compte
FROM ch03.paris_hetero
GROUP BY ar_num;

CREATE OR REPLACE VIEW ch03.vw_paris_points AS 
SELECT gid, osm_id, ar_num, geom,
    tags->'name' As place_name,
    tags->'tourism' As tourist_attraction
FROM ch03.paris_hetero
WHERE ST_GeometryType(geom) = 'ST_Point';


SELECT populate_geometry_columns('ch03.vw_paris_points');

-- Listing 3.3 Breaking our data into separate tables homogeneous geometry columns
CREATE TABLE ch03.paris_points(gid SERIAL PRIMARY KEY, 
    osm_id integer, ar_num integer, 
    feature_name varchar(200), feature_type varchar(50));
SELECT AddGeometryColumn('ch03', 'paris_points', 'geom',              --[1]
   32631,'POINT', 2);                                                 --[1]
INSERT INTO ch03.paris_points(osm_id, ar_num, geom,               --[2 BEG] 
        feature_name,
        feature_type)
SELECT osm_id, ar_num, geom, tags->'name' As feature_name, 
  COALESCE(tags->'tourism', tags->'railway', 
       'other')::varchar(50) As feature_type
FROM ch03.paris_hetero
   WHERE ST_GeometryType(geom) = 'ST_Point';                      --[2 END]
--#1 Register the geometry column
--#2 Add points 

--  Nice --
SELECT ar_num, COUNT(DISTINCT osm_id) As compte FROM 
(SELECT ar_num, osm_id FROM paris_points
UNION ALL 
SELECT ar_num, osm_id FROM paris_polygons
UNON ALL
SELECT ar_num, osm_id FROM paris_linestrings
) As X
GROUP BY ar_num;




-- Creating our abstract parent table
CREATE TABLE ch03.paris(gid SERIAL PRIMARY KEY, osm_id integer, ar_num integer, 
  feature_name varchar(200), feature_type varchar(50), geom geometry);
ALTER TABLE ch03.paris
ADD CONSTRAINT enforce_dims_geom CHECK (st_ndims(geom) = 2);
ALTER TABLE ch03.paris
ADD CONSTRAINT enforce_srid_geom CHECK (st_srid(geom) = 32631);


-- Listing 3.4 Creating a child table
CREATE TABLE ch03.paris_polygons(tags hstore,                         --[1]
    CONSTRAINT paris_polygons_pk PRIMARY KEY (gid)
)
INHERITS (ch03.paris);

ALTER TABLE ch03.paris_polygons NO INHERIT ch03.paris;            --[2]
INSERT INTO ch03.paris_polygons(osm_id, ar_num, geom,             --[3 BEG]
         tags, feature_name, feature_type)
SELECT osm_id, ar_num, ST_Multi(geom) As geom, 
    tags, tags->'name',
COALESCE(tags->'tourism', tags->'railway', 
    'other')::varchar(50) As feature_type
FROM ch03.paris_hetero
WHERE ST_GeometryType(geom) LIKE '%Polygon';
SELECT populate_geometry_columns('ch03.paris_polygons'::regclass);--[3 END]
ALTER TABLE ch03.paris_polygons INHERIT ch03.paris;               --[4]
--#1 Create an inherited table
--#2 Disinherit from parent
--#3 Load
--#4 Reinherit

-- Listing 3.5 Adding another child and adding additional constraints
CREATE TABLE ch03.paris_linestrings(                                 --[1]
    CONSTRAINT paris_linestrings_pk PRIMARY KEY (gid)                --[1]
) INHERITS (ch03.paris);                                             --[1]

ALTER TABLE ch03.paris_linestrings                                   --[2]
    ADD CONSTRAINT enforce_geotype_geom                              --[2]
    CHECK (geometrytype(geom) = 'LINESTRING'::text);                 --[2]

SELECT populate_geometry_columns('ch03.paris_linestrings'::regclass); --[3]
-- #1 Create child table
-- #2 Add geometry type constraint
-- #3 Register geometry column


SELECT ar_num, COUNT(DISTINCT osm_id) As compte 
FROM ch03.paris 
GROUP BY ar_num;

SELECT ar_num, COUNT(DISTINCT osm_id) As compte
FROM ch03.paris_polygons
GROUP BY ar_num;


-- Listing 3.6 Adopt an orphan
ALTER TABLE ch03.paris_points DROP COLUMN gid;                        --[1]
ALTER TABLE ch03.paris_points ADD COLUMN gid integer                  --[2]
   PRIMARY KEY NOT NULL DEFAULT nextval('ch03.paris_gid_seq');        --[2]
ALTER TABLE ch03.paris_points INHERIT ch03.paris;                     --[3]
CREATE INDEX idx_paris_points_geom                                    --[4]
     ON ch03.paris_points USING gist (geom);
--#1 Drop old gid
--#2 Add new gid based on parent�s sequence
--#3 Adoption
--#4 Add a spatial index

-- Listing 3.7: Making views updateable with rules
CREATE OR REPLACE VIEW ch03.stations                              --[1 BEG]
AS
SELECT gid, osm_id, ar_num, feature_name, geom
   FROM ch03.paris_points
WHERE feature_type = 'station';                                   --[1 END]
CREATE OR REPLACE RULE rule_stations_insert AS                    --[2 BEG]
   ON INSERT TO ch03.stations
   DO INSTEAD 
INSERT INTO ch03.paris_points(gid, osm_id, ar_num, 
             feature_name, feature_type, geom)
VALUES (DEFAULT, NEW.osm_id, NEW.ar_num, 
   NEW.feature_name, 'station', NEW.geom);                       --[2 END]                                      
CREATE OR REPLACE RULE rule_stations_delete AS                   --[3 BEG]
   ON DELETE TO ch03.stations
   DO INSTEAD 
DELETE FROM ch03.paris_points
WHERE gid = OLD.gid AND feature_type = 'station';               --[3 END]
CREATE OR REPLACE RULE rule_stations_update AS                  --[4 BEG]
   ON UPDATE TO ch03.stations
   DO INSTEAD 
UPDATE ch03.paris_points
SET gid = NEW.gid, osm_id = NEW.osm_id, 
        ar_num = NEW.ar_num, 
        feature_name = NEW.feature_name, geom = NEW.geom
WHERE gid = OLD.gid AND feature_type = 'station';               --[4 END] 

--#1 Read-only view
--#2 Insert-able view
--#3 Delete-able view
--#4 Updatable view

DELETE FROM ch03.stations;


   

--- To test view rules
-- delete only deletes 27 records from ch03.paris_points (representing all stations in ch03.paris_points
DELETE FROM ch03.stations;

-- Now we reinsert the stations to test our insert rule.
INSERT INTO ch03.stations(osm_id, feature_name, geom)
SELECT osm_id, tags->'name',geom
FROM ch03.paris_hetero WHERE (tags->'railway') = 'station';	

-- When we do a select on the view ch03.stations:
SELECT feature_name FROM ch03.stations 
		ORDER BY feature_name LIMIT 1;

-- We get Anvers.  Note this is the same answer we get as when we do 
SELECT feature_name FROM ch03.paris 
	WHERE feature_type = 'station' ORDER BY feature_name LIMIT 1;

-- Now to test our delete we will delete Anvers. 
DELETE FROM ch03.stations WHERE feature_name = 'Anvers';

-- and Anvers is no more.
-- To test our update, we'll change the station Victor Hugo to Victor Ergo
UPDATE ch03.stations SET feature_name = 'Victor Ergo'
WHERE feature_name = 'Victor Hugo';

-- And our original SELECT 
SELECT feature_name FROM ch03.paris 
	WHERE feature_type = 'station' AND feature_name LIKE 'Victor%' ORDER BY feature_name LIMIT 1;




-- Using triggers
-- rejects table to hold rejects
CREATE TABLE ch03.paris_rejects
(
  gid integer NOT NULL PRIMARY KEY,
  osm_id integer,
  ar_num integer,
  feature_name varchar(200),
  feature_type varchar(50),
  geom geometry, tags hstore);
  
-- Listing 3.8 PL/PGSQL BEFORE INSERT trigger function to redirect insert
CREATE OR REPLACE FUNCTION ch03.trigger_paris_insert() 
   RETURNS trigger AS
$$
DECLARE 
    var_geomtype text;
BEGIN
    var_geomtype := geometrytype(NEW.geom);                         --[1]
    IF var_geomtype IN ('MULTIPOLYGON', 'POLYGON') THEN
        NEW.geom := ST_Multi(NEW.geom);
        INSERT INTO ch03.paris_polygons(gid, osm_id, 
             ar_num, feature_name, feature_type, geom, tags)
        SELECT gid, osm_id, ar_num, feature_name, 
            feature_type, geom, tags
        FROM (SELECT NEW.*) As foo;                                 --[2]
    ELSIF var_geomtype = 'POINT' THEN
        INSERT INTO ch03.paris_points(gid, osm_id, ar_num,
               feature_name, feature_type, geom, tags)
        SELECT gid, osm_id, ar_num, feature_name, 
                 feature_type, geom, tags
        FROM (SELECT NEW.*) As foo;
    ELSIF var_geomtype = 'LINESTRING' THEN
        INSERT INTO ch03.paris_linestrings(gid, osm_id, 
             ar_num, feature_name, feature_type, geom,tags)
        SELECT gid, osm_id, ar_num, feature_name, 
                  feature_type, geom, tags
        FROM (SELECT NEW.*) As foo;
    ELSE
        INSERT INTO ch03.paris_rejects(gid, osm_id, ar_num,       --[3 BEG] 
              feature_name, feature_type, geom, tags)
        SELECT gid, osm_id, ar_num, feature_name,
                   feature_type, geom, tags 
        FROM (SELECT NEW.*) As foo;                               --[3 END]
    END IF;
    RETURN NULL;                                                     --[4]
END;
$$
LANGUAGE 'plpgsql' VOLATILE;
--#1 Using temporary variables
--#2 NEW is alias for table that contains new record
--#3 Nonstandard geometry types go into rejects table
--#4 Cancel original insert

CREATE TRIGGER trigger1_paris_insert BEFORE INSERT
ON ch03.paris FOR EACH ROW
EXECUTE PROCEDURE ch03.trigger_paris_insert();



TRUNCATE TABLE ch03.paris;

INSERT INTO ch03.paris (osm_id, geom, tags)
SELECT osm_id, geom, tags FROM ch03.paris_hetero;



--Listing 3.9 Trigger that dynamically creates tables as needed
CREATE OR REPLACE FUNCTION ch03.trigger_paris_child_insert() RETURNS TRIGGER AS $$
DECLARE
    var_sql text;
    var_tbl text;
BEGIN
    var_tbl :=  TG_TABLE_NAME || '_ar'                                --[1]
      || lpad(NEW.ar_num::text, 2, '0');                              --[1]
    IF NOT EXISTS(SELECT * FROM information_schema.tables             --[2]
              WHERE table_schema = TG_TABLE_SCHEMA                    --[2]
            AND table_name = var_tbl) THEN                            --[2]
        var_sql := 'CREATE TABLE ' || TG_TABLE_SCHEMA || '.' || var_tbl
        || '(CONSTRAINT pk_' || var_tbl || 
    	           '  PRIMARY KEY(gid) ) INHERITS (' || 
    	               TG_TABLE_SCHEMA || '.' || TG_TABLE_NAME  || ');
    	           CREATE INDEX idx_' || var_tbl || '_geom ON ' 
    	               || TG_TABLE_SCHEMA || '.' || var_tbl || ' USING gist(geom); 
    	           ALTER TABLE ' || TG_TABLE_SCHEMA || '.' || var_tbl 
    	               || ' ADD CONSTRAINT chk_ar_num CHECK (ar_num = ' || NEW.ar_num::text || ');' ;
        EXECUTE var_sql;                                              --[3]
    END IF;
    var_sql := 'INSERT INTO ' || TG_TABLE_SCHEMA                  --[4 BEG]
         || '.' || var_tbl 
         || '(gid, osm_id, ar_num, feature_name, 
            feature_type, geom, tags) 
          VALUES($1, $2, $3, $4, $5, $6, $7)';
    EXECUTE var_sql USING NEW.gid, NEW.osm_id, 
      NEW.ar_num, NEW.feature_name, NEW.feature_type, 
        NEW.geom, NEW.tags;                                       --[4 END]
    RETURN NULL;                                                      --[5]
END;
$$ language plpgsql;

--#1 Assign destination table name to variable
--#2 Check if destination table exists
--#3 Create destination table if absent
--#4 Prepare and execute insert SQL
--#5 Cancel original insert

   
-- Listing 3.10 Binding same trigger function to multiple tables
CREATE TRIGGER trig01_paris_child_insert BEFORE INSERT
    ON ch03.paris_polygons FOR EACH ROW
    EXECUTE PROCEDURE ch03.trigger_paris_child_insert();

CREATE TRIGGER trig01_paris_child_insert BEFORE INSERT
    ON ch03.paris_points FOR EACH ROW
    EXECUTE PROCEDURE ch03.trigger_paris_child_insert();

CREATE TRIGGER trig01_paris_child_insert BEFORE INSERT
    ON ch03.paris_linestrings FOR EACH ROW
    EXECUTE PROCEDURE ch03.trigger_paris_child_insert();

   
--- Testing the triggers --

TRUNCATE TABLE ch03.paris;
TRUNCATE TABLE ch03.paris_rejects;


INSERT INTO ch03.paris(osm_id, geom, tags, ar_num)
SELECT osm_id, geom, tags, ar_num
	FROM ch03.paris_hetero;

   
SELECT * FROM ch03.paris WHERE ar_num = 17;
   
---- SUPPLEMENTAL CODE NOT USED IN BOOK --
   
ALTER TABLE ch03.paris_points ADD COLUMN strno VARCHAR(20);
ALTER TABLE ch03.paris_points ADD COLUMN street VARCHAR(200);
   
-- Trigger function to populate point data
CREATE OR REPLACE FUNCTION ch03.trig_pop_data_paris_point() RETURNS TRIGGER AS $$
BEGIN
-- 1
    IF NEW.tags IS NOT NULL THEN
        NEW.feature_name := COALESCE(NEW.feature_name, NEW.tags->'name', 
	(NEW.tags->'addr:housenumber') || ' ' 
		|| (NEW.tags->'addr:street')) ;  
        NEW.feature_type := COALESCE(NEW.feature_type, NEW.tags->'tourism',
		 NEW.tags->'shop', NEW.tags->'railway',
              CASE WHEN (NEW.tags->'name') IS NOT NULL THEN 'place' 
                   WHEN (
(NEW.tags->'addr:housenumber') 
	|| (NEW.tags->'addr:street')) IS NOT NULL 
                   THEN 'address' ELSE NULL END);
        NEW.strno := COALESCE(NEW.strno, NEW.tags->'addr:housenumber');
        NEW.street := COALESCE(NEW.street, NEW.tags->'addr:street');
    END IF;
-- 2  
    RETURN NEW;
END;
$$ language plpgsql;


-- Generate dynamic data definition language (DDL) to create triggers on child point region tables that don't have triggers
SELECT 'CREATE TRIGGER trig01_pop_data_paris_point BEFORE INSERT OR UPDATE 
    ON ' || table_schema || '.' || table_name || 
    ' FOR EACH ROW 
      EXECUTE PROCEDURE ch03.trig_pop_data_paris_point();' 
FROM information_schema.tables As t LEFT JOIN information_schema.triggers As trig
    ON (t.table_schema = trig.event_object_schema AND t.table_name = trig.event_object_table)
WHERE trig.trigger_name IS NULL AND table_schema = 'ch03' AND table_name LIKE 'paris_points_ar_%';


TRUNCATE TABLE ch03.paris_objs;
TRUNCATE TABLE ch03.paris_rejects;

INSERT INTO ch03.paris(osm_id, geom, tags)
SELECT osm_id, geom, tags
	FROM ch03.paris_hetero;

	
SELECT osm_id, feature_name, feature_type, strno, street 
    FROM ch03.paris_points 
    WHERE street is not null ORDER BY street limit 1;


   