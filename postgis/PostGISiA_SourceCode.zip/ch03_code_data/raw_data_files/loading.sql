﻿-- SELECT DropGeometryTable('ch03', 'arrondissements');
CREATE SCHEMA staging;
-- at this point load the arrondissments shapefile into the staging schema using shp2pgsql or shp2pgsql-gui described in chapter 7
CREATE TABLE ch03.arrondissements(ar_num integer PRIMARY KEY, ar_name varchar(100), description varchar(100));
SELECT AddGeometryColumn('ch03', 'arrondissements', 'geom', 32631,'POLYGON', 2);

INSERT INTO ch03.arrondissements(ar_num, ar_name,  description, geom)
SELECT CAST((regexp_matches(name0, '[0-9]+'))[1] AS integer), name0, descripti0, ST_Transform(ST_GeometryN(geom,1), 32631)
FROM staging.paris_arrondissements;


SELECT (regexp_matches(name0, '[0-9]+'))[1], name0, descripti0, ST_Transform(ST_GeometryN(geom,1), 32631)
FROM staging.paris_arrondissements;

CREATE INDEX idx_arrondissements_geom
  ON ch03.arrondissements
  USING gist
  (geom);
ALTER TABLE ch03.arrondissements CLUSTER ON idx_arrondissements_geom;

CLUSTER ch03.arrondissements;

-- at this point you can follow the code described in chapter 3 and included in ch03.sql

