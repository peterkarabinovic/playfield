1) You need a PostGIS enabled database before you can load the accompanying data and scripts.
2) run hstore.sql (located in your PostgreSQL /share/contrib folder) to get the hstore datatype

There are two ways work with this chapter:
Approach 1: For the learner in a hurry -- Skip loading osm files  
a) Load ch03_data.sql using psql or PgAdmin III
b) You should now see paris_hetero, arrondissement tables in ch03 schema
c) Go straight to lessons following creating and populating paris_hetero. Basically code listings after listing 3.1-3.3


Approach 2:  Start from scratch (loading all the raw_data_files) and follow all the code in code03.sql
a) Unzip paris_arrondissements.zip in raw_data_files and load into ch03 using shp2pgsql or shp2pgsql-gui as discussed in chapters 1 and 7
b) use psql or pgAdmin3 to load in planet_osm_line.sql, planet_osm_point.sql, planet_osm_polygon.sql (or for extra excitement -- you can rebuild these files using osm2pgsql from the arctrimp.osm following instructions in Chapter 7)
c) You can now follow the exercises included in code03.sql