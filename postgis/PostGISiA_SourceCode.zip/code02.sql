CREATE TABLE my_geometries
(id serial NOT NULL PRIMARY KEY, name varchar(20));

-- Listing 2.1: Adding points
SELECT AddGeometryColumn('public','my_geometries',
   'my_points',-1,'POINT',2);
INSERT INTO my_geometries (name,my_points) 
VALUES ('Home',ST_GeomFromText('POINT(0 0)')); 
INSERT INTO my_geometries (name,my_points) 
VALUES ('Pizza 1',ST_GeomFromText('POINT(1 1)')) ;
INSERT INTO my_geometries (name,my_points) 
VALUES ('Pizza 2',ST_GeomFromText('POINT(1 -1)'));


-- Listing 2.2: Adding linestrings
SELECT AddGeometryColumn ('public','my_geometries',
  'my_linestrings',-1,'LINESTRING',2);
INSERT INTO my_geometries (name,my_linestrings) 
VALUES ('Linestring Open',
  ST_GeomFromText('LINESTRING(0 0,1 1,1 -1)')); 
INSERT INTO my_geometries (name,my_linestrings) 
VALUES ('Linestring Closed',
  ST_GeomFromText('LINESTRING(0 0,1 1,1 -1, 0 0)'));

-- Section 2.2.4 Polygons
-- Add a polygon no holes
SELECT AddGeometryColumn('public','my_geometries',
  'my_polygons',-1,'POLYGON',2);
INSERT INTO my_geometries (name,my_polygons)
VALUES ('Triangle',
  ST_GeomFromText('POLYGON((0 0, 1 1, 1 -1, 0 0))'));
  
  
-- polygon with 2 holes
INSERT INTO my_geometries (name,my_polygons)
VALUES ('Square with 2 holes',
  ST_GeomFromText('POLYGON(
  (-0.25 -1.25,-0.25 1.25,2.5 1.25,2.5 -1.25,-0.25 -1.25),
  (2.25 0,1.25 1,1.25 -1,2.25 0),(1 -1,1 1,0 0,1 -1))'));

-- Listing 2.3 Forming geometrycollections from constituent geometries
SELECT ST_AsText(ST_Collect(the_geom))
FROM (
SELECT ST_GeomFromText('MULTIPOINT(-1 1, 0 0, 2 3)') As the_geom
UNION ALL
SELECT ST_GeomFromText('MULTILINESTRING((0 0,0 1,1 1),
  (-1 1,-1 -1))') As the_geom
UNION ALL
SELECT ST_GeomFromText('POLYGON((-0.25 -1.25,-0.25 1.25,
  2.5 1.25,2.5 -1.25,-0.25 -1.25), 
  (2.25 0,1.25 1,1.25 -1,2.25 0),
 (1 -1,1 1,0 0,1 -1))') As the_geom) As foo;

Output:
GEOMETRYCOLLECTION(MULTIPOINT(-1 1,0 0,2 3),                          --#A
MULTILINESTRING((0 0,0 1,1 1),(-1 1,-1 -1)),                          --#A
POLYGON((-0.25 -1.25,-0.25 1.25,2.5 1.25,2.5 -1.25,-0.25 -1.25),      --#A
(2.25 0,1.25 1,1.25 -1,2.25 0),(1 -1,1 1,0 0,1 -1)))                  --#A

SELECT ST_AsEWKT(ST_Collect(the_geom)) FROM (
SELECT ST_GeomFromEWKT('MULTIPOINTM(-1 1 4, 0 0 2, 2 3 2)') As the_geom
UNION ALL
SELECT ST_GeomFromEWKT('MULTILINESTRINGM((0 0 1,0 1 2,1 1 3),
  (-1 1 1,-1 -1 2))') As the_geom
UNION ALL 
SELECT ST_GeomFromEWKT('POLYGONM((-0.25 -1.25 1,-0.25 1.25 2,
  2.5 1.25 3,2.5 -1.25 1,-0.25 -1.25 1), 
  (2.25 0 2,1.25 1 1,1.25 -1 1,2.25 0 2), 
(1 -1 2,1 1 2,0 0 2,1 -1 2))') As the_geom) As foo;

-- #A pictured

-- Section 2.2.6 Curved Geometries
-- Listing 2.4 Building circularstrings
SELECT AddGeometryColumn ('public','my_geometries',
  'my_circular_strings',-1,'CIRCULARSTRING',2);

INSERT INTO my_geometries(name,my_circular_strings)
VALUES ('Circle',
 ST_GeomFromText('CIRCULARSTRING(0 0,2 0, 2 2, 0 2, 0 0)')),
('Half Circle',
 ST_GeomFromText('CIRCULARSTRING(2.5 2.5,4.5 2.5, 4.5 4.5)')),
('Several Arcs',
 ST_GeomFromText('CIRCULARSTRING(5 5,6 6,4 8, 7 9, 9.5 9.5,
   11 12, 12 12)'));
   
-- compare number of points of circular string with its linearized version
SELECT name,ST_NPoints(my_circular_strings) As cnpoints, ST_NPoints(ST_CurveToLine(my_circular_strings)) As lnpoints 
  FROM my_geometries 
WHERE my_circular_strings IS NOT NULL;

-- add a compound curve constrained column and insert compound curve
SELECT AddGeometryColumn ('public','my_geometries','my_compound_curves',-1,'COMPOUNDCURVE',2);
INSERT INTO my_geometries(name,my_compound_curves)
VALUES ('Road with curve', 
  ST_GeomFromText('COMPOUNDCURVE((2 2, 2.5 2.5), 
  CIRCULARSTRING(2.5 2.5,4.5 2.5, 3.5 3.5), (3.5 3.5, 2.5 4.5, 3 5))'));


--Listing 2.5 Creating curved olygons
SELECT AddGeometryColumn ('public','my_geometries',
  'my_curve_polygons',-1,'CURVEPOLYGON',2);

INSERT INTO my_geometries(name,my_curve_polygons)
VALUES ('Solid Circle', ST_GeomFromText('CURVEPOLYGON(
  CIRCULARSTRING(0 0,2 0, 2 2, 0 2, 0 0))')), 
  ('Circle t hole', 
  ST_GeomFromText('CURVEPOLYGON(CIRCULARSTRING(2.5 2.5,4.5 2.5, 
  4.5 3.5, 2.5 4.5, 2.5 2.5), 
  (3.5 3.5, 3.25 2.25, 4.25 3.25, 3.5 3.5) )') ), 
('T arcish hole', 
  ST_GeomFromText('CURVEPOLYGON((-0.5 7, -1 5, 3.5 5.25, -0.5 7), 
CIRCULARSTRING(0.25 5.5, -0.25 6.5, -0.5 5.75, 0 5.75, 0.25 5.5))'));
