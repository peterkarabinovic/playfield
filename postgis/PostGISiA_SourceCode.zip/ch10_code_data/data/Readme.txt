In a PostGIS 1.5+ enabled database

Get into psql (TIP: You can launch psql from PgAdmin Plugins menu - make sure to select the databae first)
run
\i /path/to/ch10_data.sql

--- alternatively --
"C:\Program Files\PostgresQL\8.4\bin\psql" -h localhost -d postgis_in_action -U postgres -f ch10_data.sql