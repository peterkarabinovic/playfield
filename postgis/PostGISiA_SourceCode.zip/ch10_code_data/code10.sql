-- Listing 10.1 Example of geocode function
SELECT 
	-- 1 output rading
g.rating,
-- 2  output longitude and latitude from postgis point
	ST_X(geomout) As lon, 
	ST_Y(geomout) As lat, 
-- 3 output all properties of normalize return address
(addy).* 
FROM geocode('1731 New Hampshire Avenue Northwest, Washington, DC 20010') As g;



-- Listing 10.2 Listing specific elements of addy in geocode results
SELECT g.rating, 
-- 1 round coordinates
	round(ST_X(g.geomout)::numeric,5) As lon, 
	round(ST_Y(g.geomout)::numeric,5) As lat, 
-- 2 reformat and select specific addy fields
	(g.addy).address As snum,
	(g.addy).streetname || ' ' || (g.addy).streettypeabbrev As street,
	(g.addy).zip
FROM geocode('1021 New Hampshare Avenue, Washington, DC 20010') As g;


-- Listing 10.3 Create dummy records to batch geocode
set search_path = ch10, public, tiger;
-- 1 create test data
CREATE TABLE addr_to_geocode(addid serial NOT NULL PRIMARY KEY, 
	rating integer, 
	address text, 
	norm_address text, pt geometry);
INSERT INTO addr_to_geocode(address)
	VALUES ('1000 Huntington Street, DC'),
		('4758 Reno Road, DC 20017'),
		('1021 New Hampshare Avenue, Washington, DC 20010');
-- 2 batch geocoding		
UPDATE addr_to_geocode
-- 3 multicolumn update
	SET  (rating, norm_address, pt) 
		= (g.rating, 
			COALESCE ((g.addy).address::text, '') 
			|| COALESCE(' ' || (g.addy).predirabbrev, '') 
			|| COALESCE(' ' || (g.addy).streetname,'') 
|| ' ' || COALESCE(' ' || (g.addy).streettypeabbrev, '') 
	|| COALESCE(' ' || (g.addy).location || ', ', '')
	|| COALESCE(' ' || (g.addy).stateabbrev, '') 
|| COALESCE(' ' || (g.addy).zip, '')
					,
				ST_SnapToGrid(g.geomout, 0.000001)
				)
-- 4 just one rec per addid 
FROM (SELECT DISTINCT ON (addid) addid, (g1.geo).*
	FROM (SELECT addid,  (geocode(address)) As geo
FROM addr_to_geocode As ag
	WHERE ag.rating IS NULL ) As g1
-- 5 pick lowest rating
ORDER BY addid, rating) As g
WHERE g.addid = addr_to_geocode.addid;


/** General comment  - NOT to run **/
-- note this is the ANSI standard way supported by Oracle, but sadly PostgreSQL does not support a SELECT multicolumn construct use subsekect
UPDATE addr_to_geocode
	SET (rating, norm_address, pt) 
		= (SELECT g.rating, 
				(g.addy).address || COALESCE(' ' || (g.addy).predirabbrev, '') 
					|| ' ' || (g.addy).streetname || ' ' || (g.addy).streettypeabbrev,
				ST_SnapToGrid(g.geomout, 0.000001)
				FROM geocode(addr_to_geocode.address) As g
					ORDER BY g.rating
					LIMIT 1);
/** End General comment **/

-- normalize address example --
SELECT foo.address As orig_addr, (foo.na).* 
  FROM (SELECT address, normalize_address(address) As na
     FROM addr_to_geocode) AS foo;

					
-- PL/R examples start here

-- Listing 10.4 Saving PostgreSQL data in R data format with PL/R
CREATE OR REPLACE FUNCTION ch10.save_dc_rdata() RETURNS text AS
$$
	dccounties <<- pg.spi.exec("SELECT cntyidfp, name, intptlat, intptlon
					FROM county WHERE statefp = '11'")
					
	dczips <<- pg.spi.exec("SELECT z.zcta5ce, z.intptlat, z.intptlon
					FROM zcta500 AS z INNER JOIN state As s ON ST_Intersects(z.the_geom, s.the_geom)
					WHERE statefp = '11'")
	save(dccounties,dczips, file="C:/Temp/dc.RData")
	return("done")
$$
language 'plr';

SELECT ch10.save_dc_rdata();

-- Listing 10.5 viewing data in R GUI not shown 

-- Listing 10.6 Plotting with PL/R
CREATE OR REPLACE FUNCTION ch10.graph_income_house() RETURNS text AS
$$
randdata <<- pg.spi.exec("SELECT x As income , 
	Avg(x*(1 + random()*y) ) As avgprice
        FROM generate_series(2000,100000, 10000) As x 
		CROSS JOIN generate_series(1,5) As y
            GROUP BY x ORDER BY x")
png('C:/temp/housepercap.png', width=500, height=400)
opar <- par(bg = "white") #set background color
plot(x=randdata$income,y=randdata$avgprice, ann = FALSE, type = "n")
yrange = range(randdata$avgprice)
#create horizontal grid lines
abline(h=seq(yrange[1],yrange[2],(yrange[2] - yrange[1])/10), lty=1, col="grey")
lines(x=randdata$income,y=randdata$avgprice, col = "green4", lty = "dotted")
points(x=randdata$income,y=randdata$avgprice, bg = "limegreen", pch = 23)
title(main = "Random plot of house price vs. per capita income",
      xlab = "Per cap income", ylab = "Average House Price",
      col.main = "blue", col.lab = "red1",
      font.main = 4, font.lab = 3)

dev.off()
return("done")

$$
LANGUAGE 'plr';

SELECT ch10.graph_income_house();

-- Listing 10.9 Function to get list of supported RGDAL raster formats
CREATE OR REPLACE FUNCTION r_getgdaldrivers() RETURNS SETOF text AS
$$
	library(rgdal)
	# gdalDrivers() returns a data.frame of which we only want the long_name
	return(gdalDrivers()['long_name'])
$$
language 'plr';

SELECT driver 
	FROM r_getgdaldrivers() As driver
	WHERE driver ILIKE '%arc%'
	ORDER BY lower(driver);
	
--Listing 10.10 Demonstrating subset and c functions in R
CREATE OR REPLACE FUNCTION r_getgdaldrivers(param_create boolean, param_copy boolean) RETURNS SETOF text AS
$$
	library(rgdal)
	# gdalDrivers() returns only those that match our create, 
	# copy desired setting and only return long_name field
	return (subset(
			gdalDrivers(), 
			create==param_create & copy==param_copy, select=c(long_name))
		)
$$
language 'plr';

SELECT driver 
	FROM r_getgdaldrivers(true,true) As driver
	ORDER BY lower(driver);



-- Listing 10.11 Reading meta data from Image files with rgdal

CREATE TYPE gdalinfo_values AS(key text, value text);

CREATE OR REPLACE FUNCTION r_getimageinfo(param_file text) 
	returns SETOF gdalinfo_values AS
$$
    library(rgdal)
    tile_summary <-GDALinfo(param_file)
    result_labels <- labels(tile_summary)
    result_values <- tile_summary[result_labels]
    df <- data.frame(key = result_labels, value = result_values);
    return(df)
$$
language 'plr';

SELECT * FROM r_getimageinfo('C:/winter.jpg');

-- Listing 10.12 Plotting linestrings with R
-- Note this uses PostGIS 1.5 ST_DumpPoints, if you are running a lower version of PostGIS 
-- You can still use it by installing the plpgsql function from PostGIS 1.5 download file
CREATE OR REPLACE FUNCTION ch10.plot_routing_results()
  RETURNS text AS
$$
	library(sp)
	#explode the points
	geodata <<- pg.spi.exec("SELECT gid, ST_X(geom) As x, ST_Y(geom) As y, 
					path[1] As ptn
			FROM 
				(SELECT gid, route, (ST_DumpPoints(the_geom)).* 
					FROM ch10.twin_cities
					) As c ORDER BY gid, path[1]")
					
	georesult <<- pg.spi.exec("SELECT ST_X(geom) As x, ST_Y(geom)As y
					FROM 
					(SELECT (ST_DumpPoints( ST_LineMerge(ST_Collect(the_geom)) )).* 
					FROM ch10.dijsktra_result ) As r
						ORDER BY path[1]")
					
	geo.fact <- factor(geodata$gid)				
	geo.id <- levels(geo.fact) #get unique list of linestring ids
	ngeom <- length(geo.id)
	
	geo.xy <- split(geodata[2:3], geo.fact) #regroup points by line they belong to
	geo.geoms <- list()
	for(k in 1:ngeom ){
		geo.geoms[k] = Lines(list(Line(geo.xy[k])), ID = geo.id[k]) 	
	}
	# add the result
	geo.result <- SpatialLines( list ( Lines( list(Line(cbind(georesult$x,georesult$y))) , ID='result') ) )
	geo.sp <- SpatialLines(geo.geoms)

	sdf <- SpatialLinesDataFrame(geo.sp, data = data.frame(geo.id, row.names="geo.id" ), match.ID = TRUE)  
	sdf_result <- SpatialLinesDataFrame(geo.result, data = data.frame(c("result") ), match.ID=FALSE )

	png('C:/temp/twin_bestpath.png', width=500, height=400)

	#show axes, limit axes with xlim, ylim range
	plot(sdf,xlim=c(-94, -93),ylim=c(44.5,45.5),axes=TRUE);
	
	lines(sdf_result, col = "green4", lty = "dashed", type="o")
	
	title(main= "Travel options to Twin Cities", font.main=4, col.main="red", xlab="Longitude", ylab="Latitude")
	dev.off()
	return("done")
$$
  LANGUAGE 'plr' VOLATILE;
SELECT ch10.plot_routing_results();
					
-- PL/Python examples start here ---

-- Listing 10.13 Compute sum of range of numbers
-- Example use: SELECT fnaddreduce(1,4); ==> 10
CREATE OR REPLACE FUNCTION fnaddreduce(param_start integer, 
		param_end integer)
  RETURNS integer AS
$$
# define add function 
def add(x,y): return x+y

# return sum from range param_start to param_end
return reduce(add, range(param_start, param_end + 1));
$$
  LANGUAGE 'plpythonu' IMMUTABLE;
  
-- Listing 10. get tile info
CREATE OR REPLACE FUNCTION fngettileinfo(param_filename text)
RETURNS text AS
$$
from osgeo import gdal
return ''

$$
	LANGUAGE 'plpythonu' VOLATILE;
	
-- Listing 10.14 Reading excel files get file summary
CREATE OR REPLACE FUNCTION fngetfileinfo(param_filename text, OUT property text, OUT value text)
RETURNS text AS
$$
	import xlrd
	result = str('');
	book = xlrd.open_workbook(param_filename)
	result = result + str("The number of worksheets is") + str(book.nsheets)
	result = result + str("Worksheet name(s):") + str(book.sheet_names())
	sh = book.sheet_by_index(0)
	result = result + str(sh.name) + ' ' + str(sh.nrows) + ' '+  str(sh.ncols)
	result = result + "Cell A1 is", str(sh.cell_value(rowx=1, colx=1))
	return result
$$
	LANGUAGE 'plpythonu' VOLATILE;


--- Listing 10.15 import excel data points into geometry point columns	
CREATE TYPE ch10.place_lon_lat AS (
  place text,
  lon float,
  lat float
);
CREATE OR REPLACE FUNCTION ch10.fngetxlspts(param_filename text)
RETURNS SETOF ch10.place_lon_lat AS
$$
	import xlrd
	book = xlrd.open_workbook(param_filename)
	sh = book.sheet_by_index(0)
	# we will assume that the first row contains 
	# the header columns so skip it
	for rx in range(1,sh.nrows):
		yield(sh.cell_value(rowx=rx, colx=0), 
			sh.cell_value(rowx=rx, colx=1), 
			sh.cell_value(rowx=rx, colx=2)
			)
$$
	LANGUAGE 'plpythonu' VOLATILE;
	

CREATE TABLE ch10.imported_places(place_id serial PRIMARY KEY, place text, geom geometry);
INSERT INTO ch10.imported_places(place, geom)
SELECT place, ST_SetSRID(ST_Point(lon,lat),4326)
FROM ch10.fngetxlspts('C:/Temp/Test.xls') AS foo;

-- Listing 10.16 Listing documents in a directory with PL/Python
CREATE FUNCTION ch10.list_files(param_filepath text) RETURNS SETOF text 
AS
$$
	import os
	return os.listdir(param_filepath)
$$
LANGUAGE 'plpythonu' VOLATILE;

-- SQL Wrapper to allow us to safely iterate the python file list
CREATE OR REPLACE FUNCTION ch10.fnsqlgetxlspts(param_filename text)
	RETURNS SETOF ch10.place_lon_lat AS
$$
	SELECT * FROM ch10.fngetxlspts($1);
$$
 LANGUAGE 'sql' VOLATILE;
 
-- Listing 10.17  pull a distinct set of data from a set of excel files
INSERT INTO ch10.imported_places(place, geom)
SELECT place, ST_SetSRID(ST_Point(lon,lat),4326)
FROM (SELECT DISTINCT (ch10.fnsqlgetxlspts('C:/Temp/' || file)).* 
	FROM ch10.list_files('C:/Temp') AS file
	WHERE file LIKE 'Test%.xls') As d;
	
	
-- Listing 10.18 Creating a geocoder built on google maps
CREATE TYPE ch10.google_lon_lat AS (lon numeric, lat numeric);
CREATE FUNCTION ch10.google_geocode(param_address text) 
	RETURNS ch10.google_lon_lat
AS
$$
 from googlemaps import GoogleMaps
 gmaps = GoogleMaps()
 arg_lat, arg_long = gmaps.address_to_latlng(param_address)
 return (arg_long, arg_lat)
$$
language 'plpythonu';

	


