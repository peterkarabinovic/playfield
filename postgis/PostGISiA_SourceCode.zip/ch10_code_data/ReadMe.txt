For the exercises in this chapter:

About data:
twin_cities are roads subset from roads data in chapter 1.
spain_nuclear_plants consists of spain nuclear power lon lat locations.

1) The ch10_data.sql builds ch10 chapter schema with relevant tables.
2) You'll need your search_path to include: ch10, public and for R exercises -- tiger as well;
3) For the R  exercises, you'll need your search path to also include tiger.

So ALTER DATABASE postgis_in_action SET search_path=public,ch10,tiger;
or:
--or if you prefer setting at session:
SET search_path=public,ch10,tiger;

-- PgRouting --
Note: Many of the pgRouting exercises in the book will not work unless public is first in search_path.
Instructions described in: http://www.pgrouting.org/docs/1.x/install.html

You need to load the following: (where /usr/share/postlbs replace with the location of your PgRouting scripts)
psql -U postgres -f /usr/share/postlbs/routing_core.sql postgis_in_action
psql -U postgres -f /usr/share/postlbs/routing_core_wrappers.sql postgis_in_action
psql -U postgres -f /usr/share/postlbs/routing_topology.sql postgis_in_action

3. Add pgRouting extra functions (these may not be in a binary install, but can be found in extras/tsp of the postlbs source tar ball
http://www.pgrouting.org/download.html (1.03 was what we used)
# With TSP
psql -U postgres -f /usr/share/postlbs/routing_tsp.sql postgis_in_action
psql -U postgres -f /usr/share/postlbs/routing_tsp_wrappers.sql postgis_in_action


--- We don't show any driving direction examples so this is not needed for exercises
# With Driving Distance (optional) 
psql -U postgres -f /usr/share/postlbs/routing_dd.sql postgis_in_action
psql -U postgres -f /usr/share/postlbs/routing_dd_wrappers.sql postgis_in_action