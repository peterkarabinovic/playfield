-- seciton 4.1.1 examples
-- bulk table insert using ST_GeomFromtText
SELECT * INTO table1 
FROM ( VALUES 
    ( ST_GeomFromText('POINT(-100 28)', 4326) ),
    ( ST_GeomFromText('LINESTRING(-80 28, -90 29)', 4326) ),
    ( ST_GeomFromText('POLYGON((10 28, 9 29, 7 30, 10 28))' ) ) ) As foo(geom);


-- Bulk table insert using ST_GeomFromEWKT    
SELECT * INTO table2 
FROM ( VALUES 
    (ST_GeomFromEWKT('SRID=4326;POINT(-100 28)')),
    (ST_GeomFromEWKT('SRID=4326;LINESTRING(-80 28,-90 29)')),
    (ST_GeomFromEWKT('SRID=4326;POLYGON((10 28, 9 29, 7 30, 10 28))' ) ) ) As foo(geom);

    
-- using WKB
SELECT ST_GeomFromWKB(E'\\001\\001\\000\\000\\000\\321\\256B\\312O\\304Q\\300\\347\\030\\220\\275\\336%E@',4326);


SELECT
ST_AsBinary(ST_GeomFromWKB(E'\\001\\001\\000\\000\\000\\321\\256B\\312O\\304Q\\300\\347\\030\\220\\275\\336%E@',4326));

-- using standard conforming sql strings
set standard_conforming_strings = on;
SELECT ST_GeomFromWKB('\001\001\000\000\000\321\256B\312O\304Q\300\347\030\220\275\336%E@');

-- seciotn 4.1.2 exmaples: Autocasting
SELECT ST_Centroid('LINESTRING(1 2,3 4)');

SELECT ST_AsText(ST_Centroid('LINESTRING(1 2,3 4)'));

SELECT ST_Centroid(ST_GeomFromText('LINESTRING(1 2,3 4)'));

SELECT ST_Box3D('BOX(1 2, 3 4)');

SELECT ST_XMin('LINESTRING(1 2, 3 4)');

SELECT ST_XMin('LINESTRING(1 2, 3 4)'::geometry::box3d);

-- Section 4.2.7 examples of output functions
SELECT ST_AsGML(geom,5) as GML, ST_AsKML(geom,5) As KML, ST_AsGeoJSON(geom,5) As GeoJSON, ST_AsSVG(geom,0,5) As SVG_Absolute, ST_AsSVG(geom,1,5) As SVG_Relative, ST_GeoHash(geom) As Geohash
FROM (SELECT ST_GeomFromText('LINESTRING(2 48, 0 51)', 4326) As geom) foo;


-- Section 4.3.1 Getting and setting spatial reference system 
-- Listing 4.1 Example use of ST_SRID
--[1 Beg]
SELECT ST_SRID(ST_GeomFromText('POLYGON((1 1, 2 2, 2 0, 1 1))', 4326));
--[1 End]
--[2 Beg]
SELECT ST_SRID(geom) As srid, COUNT(*) As number_of_geoms 
FROM sometable 
GROUP BY ST_SRID(geom);
--[2 End]
--[3 Beg]
SELECT ST_SRID(geom) As srid, ST_SRID(ST_SetSRID(geom,4326)) as srid_new
FROM (VALUES (ST_GeomFromText('POLYGON((70 20, 71 21, 71 19, 70 20))', 4269)), (ST_Point(1,2))) As foo (geom);
--[3 End]

--[1] Simple use of ST_SRID
--[2] Counts number of distinct SRIDs
--[3] Using ST_SetSRID to change SRID

-- Section 4.3.2 Examples: Transform to a different spatial reference
SELECT ST_AsEWKT(ST_Transform(ST_GeomFromEWKT('SRID=4326;LINESTRING(-73 41, -72 42)'), 32618));

--Listing 4.2 Differences in output between ST_GeometryType and GeometryType
SELECT ST_GeometryType(geom) As new_name, GeometryType(geom) As old_name
FROM (VALUES 
(ST_GeomFromText('POLYGON((0 0, 1 1, 0 1, 0 0))')),
(ST_Point(1, 2)),
(ST_MakeLine(ST_Point(1, 2), ST_Point(1, 2))),
(ST_Collect(ST_Point(1, 2), ST_Buffer(ST_Point(1, 2),3))),
(ST_LineToCurve(ST_Buffer(ST_Point(1, 2), 3))),
(ST_LineToCurve(ST_Boundary(ST_Buffer(ST_Point(1, 2), 3)))),
(ST_Multi(ST_LineToCurve(ST_Boundary(ST_Buffer(ST_Point(1, 2),3)))))
) As foo (geom);

-- example using case to output conditional measures
SELECT CASE WHEN GeometryType(geom) = 'POLYGON' THEN ST_Area(geom) 
WHEN GeometryType(geom) = 'LINESTRING' THEN ST_Length(geom) ELSE NULL END As measure FROM table1;


-- Listing 4.3 Coordinate and geometry dimensions of various geometries
SELECT item_name, ST_Dimension(geom) As gdim, ST_CoordDim(geom) as cdim
FROM ( VALUES ('2d polygon' , 
ST_GeomFromText('POLYGON((0 0, 1 1, 1 0, 0 0))') ),
('2d polygon with hole' , 
ST_GeomFromText('POLYGON ((-0.5 0, -1 -1, 0 -0.7, -0.5 0), 
	(-0.7 -0.5, -0.5 -0.7, -0.2 -0.7, -0.7 -0.5))') ),
( '2d point', ST_Point(1,2) ),
( '2d line' , ST_MakeLine(ST_Point(1,2), ST_Point(3,4)) ),
( '2d collection', ST_Collect(ST_Point(1,2), ST_Buffer(ST_Point(1,2),3)) ),
( '2d curved polygon', ST_LineToCurve(ST_Buffer(ST_Point(1,2), 3)) ) ,
( '2d circular string', 
	ST_LineToCurve(ST_Boundary(ST_Buffer(ST_Point(1,2), 3))) ),
( '2d multicurve', 	ST_Multi(ST_LineToCurve(ST_Boundary(ST_Buffer(ST_Point(1,2), 3)))) ),
('3d polygon' , ST_GeomFromText('POLYGON((0 0 1, 1 1 1, 1 0 1, 0 0 1))') ),
('2dm polygon' ,
	ST_GeomFromText('POLYGONM((0 0 1, 1 1 1.25, 1 0 2, 0 0 1))') ),
('3d(zm) polygon' , 
	ST_GeomFromEWKT('POLYGON((0 0 1 1, 1 1 1 1.25, 1 0 1 2, 0 0 1 1))')  ),
('4d (zm) multipoint' , 
	ST_GeomFromEWKT('MULTIPOINT(1 2 3 4, 4 5 6 5, 7 8 9 6)')  )
 ) As foo(item_name, geom);


-- Listing 4.4 Example of ST_NPoints and ST_NumPoints
SELECT atype, ST_NPoints(geom) As npoints, ST_NumPoints(geom) As numpoints
FROM (VALUES ('LinestringM' , ST_GeomFromEWKT('LINESTRINGM(1 2 3, 3 4 5, 5 8 7, 6 10 11)')),
 ('Circularstring', ST_GeomFromText('CIRCULARSTRING(2.5 2.5, 4.5 2.5, 4.5 4.5)')),
('Polygon (Triangle)', ST_GeomFromText('POLYGON((0 1,1 -1,-1 -1,0 1))')),
('Multilinestring', ST_GeomFromText('MULTILINESTRING ((1 2, 3 4, 5 6), (10 20, 30 40))')),
('Collection', ST_Collect(ST_GeomFromText('POLYGON((0 1,1 -1,-1 -1,0 1))'), ST_Point(1,3)))
) As foo(type, geom);


-- Section 4.4.1 examples Planar measures for geometry types
SELECT ST_Length(geom) As length_2d, ST_Length3D(geom) As length_3d
FROM (VALUES(ST_GeomFromEWKT('LINESTRING(1 2 3, 4 5 6)')), ST_GeomFromEWKT('LINESTRING(1 2, 4 5)'))) As foo(geom);



-- Section 4.4.2 Geodetic measurement for geometry types
-- Listing 4.5 Examples of calculating length of a multilinestring with different spheroids and compare with different transforms
-- 1
SELECT sp_name, geom_name,
    ST_Length_Spheroid(g.geom, s.the_spheroid) As sp3d_length, ST_Length3D(ST_Transform(g.geom, 26986)) As ma_state_m,
      ST_Length3D(ST_Transform(g.geom, 2163)) As us_nat_atl_m
FROM (VALUES ('2d line', ST_GeomFromText('MULTILINESTRING((-71.205 42.531,-71.204 42.532), (-71.21 42.52, -71.211 42.52))',4326)),
 ('3d line', ST_GeomFromEWKT('SRID=4326;MULTILINESTRING((-71.205 42.531 10,-71.205 42.531 15,-71.204 42.532 16, -71.204 42.532 18),
    (-71.21 42.52 0,-71.211 42.52 0))') )
  
) As g(geom_name, geom)
CROSS JOIN
-- 2
  (VALUES ('grs 1980', CAST('SPHEROID["GRS_1980",6378137,298.257222101]' As spheroid)),
      ('wg 1984', CAST('SPHEROID["WGS_1984",6378137,298.257223563]' As spheroid)  )
      ) As s(sp_name, the_spheroid); 
-- 1 geometries
-- 2 spheroids 


-- Listing 4.6 Compare spheroid and sphere calculations in geography
SELECT name, ST_Length(geog) As sp3d_lengthspheroid, ST_Length(geog, false) As sp3d_lengthsphere
FROM (VALUES ('2D Multilinestring', 
        ST_GeogFromText('SRID=4326;MULTILINESTRING((-71.205 42.531, -71.204 42.532), (-71.21 42.52, -71.211 42.52))')),
 ('3D Multilinestring', ST_GeogFromText('SRID=4326;MULTILINESTRING((-71.205 42.531 10, -71.205 42.531 15, -71.204 42.532 16,-71.204 42.532 18), (-71.21 42.52 0, -71.211 42.52 0))'))
) As foo (name, geog);  


-- Section 4.5 Decomposition
-- Listing 4.7 ST_Box2D and casting a box to a geometry
SELECT name, ST_Box2D(geom) As box, ST_AsEWKT(CAST(geom As geometry)) As box_casted_as_geometry
FROM (
VALUES 
('2D linestring', ST_GeomFromText('LINESTRING(1 2, 3 4)')),
('Vertical linestring', ST_GeomFromText('LINESTRING(1 2, 1 4)')), 
('Point', ST_GeomFromText('POINT(1 2)')), 
('Polygon', ST_GeomFromText('POLYGON((1 2, 3 4, 5 6, 1 2))')))
AS foo(name, geom);


-- Listing 4.8 Example of ST_Envelope
SELECT name, ST_Box2D(geom) AS box, ST_AsEWKT(ST_Envelope(geom)) AS env
FROM (
VALUES 
('2D linestring', ST_GeomFromText('LINESTRING(1 2, 3 4)')),
('Vertical linestring', ST_GeomFromText('LINESTRING(1 2, 1 4)')), 
('Point', ST_GeomFromText('POINT(1 2)')), 
('Polygon', ST_GeomFromText('POLYGON((1 2, 3 4, 5 6, 1 2))'))
) 
AS foo(name, geom);

-- Listing 4.9 Example of ST_Boundary
SELECT name, ST_AsText(ST_Boundary(geom)) As WKT
FROM (VALUES 
('Simple linestring', ST_GeomFromText('LINESTRING(-14 21,0 0,35 26)')),
('Non-simple linestring', ST_GeomFromText('LINESTRING(2 0,0 0,1 1,1 -1)')),
('Closed linestring', ST_GeomFromText('LINESTRING(52 218, 139 82, 262 207, 245 261, 207 267, 153 207, 125 235, 90 270, 55 244, 51 219, 52 218)')),
('Polygon', ST_GeomFromText('POLYGON((52 218, 139 82, 262 207, 245 261, 207 267, 153 207, 125 235, 90 270, 55 244, 51 219, 52 218))')),
 ('Polygon with holes', ST_GeomFromText('POLYGON((-0.25 -1.25,-0.25 1.25,2.5 1.25,2.5 -1.25,-0.25 -1.25),(2.25 0,1.25 1,1.25 -1,2.25 0),(1 -1,1 1,0 0,1 -1))'))
)
AS foo(name, geom);


-- Listing 4.10 Centroid of various geometries
SELECT name, ST_AsEWKT(ST_Centroid(geom)) As centroid, ST_AsEWKT(ST_PointOnSurface(geom)) As point_on_surface
FROM (VALUES ('Multipoint', ST_GeomFromEWKT('MULTIPOINT(-1 1, 0 0, 2 3)')),
('Multipoint 3D', ST_GeomFromEWKT('MULTIPOINT(-1 1 1, 0 0 2, 2 3 1)')),
('Multilinestring', ST_GeomFromEWKT('MULTILINESTRING((0 0,0 1,1 1),(-1 1,-1 -1))')),
('Polygon', ST_GeomFromEWKT('POLYGON((-0.25 -1.25,-0.25 1.25,2.5 1.25, 2.5 -1.25,-0.25 -1.25), (2.25 0,1.25 1,1.25 -1,2.25 0), (1 -1,1 1,0 0,1 -1))')))
As foo(name, geom);

-- deomstration of point n
SELECT ST_AsText(ST_PointN(ST_GeomFromText('LINESTRING(1 2, 3 4, 5 8)'), 2));



-- ST_Dump example
SELECT gid, (ST_Dump(geom)).path As exploded_path, ST_AsEWKT((ST_Dump(geom)).geom) As exploded_geometry
FROM (VALUES (1, ST_GeomFromEWKT('MULTIPOLYGONM(((2.25 0 3,1.25 1 2,1.25 -1 3,2.25 0 1)),((1 -1 1,1 1 2,0 0 1,1 -1 1)))')), (2, ST_GeomFromEWKT('GEOMETRYCOLLECTION(MULTIPOLYGON(((2.25 0,1.25 1,1.25 -1,2.25 0)),((1 -1,1 1,0 0,1 -1)) ), MULTIPOINT(1 2, 3 4), LINESTRING(5 6, 7 8), MULTICURVE(CIRCULARSTRING(1 2, 0 4, 2 8), (1 2, 5 6)))'))
) As foo(gid, geom);


-- Listing 4.11 Example using ST_GeometryN with generate_series
SELECT gid, ST_AsEWKT(ST_GeometryN(geom, generate_series(1,ST_NumGeometries(geom)))) As extracted_geometry
FROM (VALUES (1, ST_GeomFromEWKT('MULTIPOLYGONM(((2.25 0 3, 1.25 1 2, 1.25 -1 3, 2.25 0 1)), ((1 -1 1, 1 1 2, 0 0 1, 1 -1 1)))')), (2, ST_GeomFromEWKT('GEOMETRYCOLLECTION(MULTIPOLYGON(((2.25 0, 1.25 1, 1.25 -1, 2.25 0)), ((1 -1, 1 1, 0 0, 1 -1))), MULTIPOINT(1 2, 3 4), LINESTRING(5 6, 7 8), MULTICURVE(CIRCULARSTRING(1 2, 0 4, 2 8), (1 2, 5 6)))'))
) As foo(gid, geom);


-- ST_ExterioRing, ST_InteriorRing example
SELECT ST_AsText(ST_ExteriorRing(geom)) As exterior_ring, ST_AsText(ST_InteriorRingN(geom,1)) As interior_ring1
FROM ST_GeomFromText('POLYGON((-0.25 -1.25,-0.25 1.25,2.5 1.25, 2.5 -1.25,-0.25 -1.25), (2.25 0,1.25 1,1.25 -1,2.25 0), (1 -1,1 1,0 0,1 -1))') As geom;


-- Section 4.6 Composition functions

-- Listing 4.12  Point constructor functions
SELECT whale, ST_AsEWKT(spot) As spot
FROM 
(VALUES 
('Mr. Whale', ST_SetSRID(ST_Point(-100.499, 28.7015), 4326)), 
--[1 Beg]
('Mr. Whale with M as time', ST_SetSRID(ST_MakePointM(-100.499, 28.7015, 5), 4326)), 
--[1 End]
--[2 Beg]
('Mr. Whale with Z as depth', ST_SetSRID(ST_MakePoint(-100.499, 28.7015, 0.5), 4326)), 
--[2 End]
('Mr. Whale with M and Z', ST_SetSRID(ST_MakePoint(-100.499, 28.7015, 0.5, 5), 4326))
) As foo(whale, spot);
-- [1] Whale with time
-- [2] Whale with depth
-- [3] Whale with time and depth


-- Listing 4.13 ST_Polygonize , ST_BuildArea, ST_MakePolygon
--[1 Beg]
SELECT geom
INTO example
FROM (
(VALUES(ST_GeomFromText('LINESTRING(1 2, 3 4, 4 4, 1 2)')), 
(ST_GeomFromEWKT('MULTILINESTRING((0 0, 4 4, 4 0, 0 0), (2 1, 3 1, 3 2, 2 1))'))) ) As e(geom);
--[1 End]
--[2 Beg]
SELECT 'ST_MakePolygon (1)' As function, ST_AsEWKT(ST_MakePolygon(geom)) As polygon
FROM example
WHERE ST_GeometryType(geom) = 'ST_LineString'
--[2 End]
UNION ALL
--[3 Beg]
SELECT 'ST_MakePolygon (2)' As function, ST_AsEWKT(ST_MakePolygon(ST_GeometryN(geom, 1), ARRAY[(SELECT ST_GeometryN(geom, n) FROM generate_series(2, ST_NumGeometries(geom)) As n )])) As polygon
FROM example
WHERE ST_GeometryType(geom) = 'ST_MultiLineString'
UNION ALL
SELECT 'ST_BuildArea' As function, ST_AsEWKT(ST_BuildArea(geom)) As polygon
FROM example
UNION ALL
SELECT 'ST_Polygonize' As function, ST_AsEWKT(ST_Polygonize(geom)) As polygon
FROM example;
--[3 End]

-- [1] make example table
-- [2] polygon with no holes
-- [3] polygons with holes

-- Section 4.7 Simplification
-- Coordinate rounding
SELECT pow(10, -1*n)*5 As tolerance, 
ST_AsEWKT(ST_SnapToGrid(ST_GeomFromEWKT('SRID=4326;LINESTRING(-73.81309 41.74874, -73.81276 41.74893, -73.812765 41.74895, -73.81307 41.74896)'), pow(10, -1*n)*5)) As simplified_geometry
FROM generate_series(3,6) As n
ORDER BY tolerance;



-- ST_Simplify and ST_SimplyfyPreserveTopology
SELECT pow(2, n) as tolerance, ST_AsText(ST_Simplify(geom, pow(2, n))) As ST_Simplify, ST_AsText(ST_SimplifyPreserveTopology(geom, pow(2, n))) As ST_SimplifyPreserveTopology
FROM (SELECT ST_GeomFromText('POLYGON((10 0, 20 0, 30 10, 30 20, 20 30, 10 30, 0 20, 0 10, 10 0))') As geom
) As foo CROSS JOIN generate_series(2,4) As n;
